# research02 — an AI agent does the search

Version 2 does the same Tavily search as version 1, but an agent makes the
call. The search becomes a tool, the model decides to use it, and
`return_direct=True` means the tool's result is the final answer — so the ten
raw results come back untouched, with no summary written on top of them.

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with two lines:

   ```
   TAVILY_API_KEY=your-tavily-key
   DEEPSEEK_API_KEY=your-deepseek-key
   ```

   A Tavily key is available from the [Tavily dashboard](https://app.tavily.com/home),
   and a DeepSeek key from the [DeepSeek console](https://platform.deepseek.com/api_keys).
3. In the Terminal, run these three lines, one at a time:

   ```
   uv python pin 3.12.10
   uv sync
   uv run research02.py
   ```

This version calls a language model once, so it needs both keys. It takes a
few seconds.

## What to look at

- `search_internet` — the Tavily call from version 1, now marked with `@tool`.
  The docstring is what the model reads when deciding to use it.
- `return_direct=True` — the agent stops once the tool answers, so nothing is
  summarised.
- The system prompt — the model is told to call the tool and to leave the
  question exactly as typed.
- `Search result:` — only the tool's message is printed; the question and the
  model's tool request are skipped.

## Try it

- Change the question and check that the `Query:` line matches what you typed.
- Remove `return_direct=True` and run it again: the model will now write a
  summary after the tool, which is what this version deliberately avoids.

## Limitations

- The agent adds a step, not an answer. The results are the same ten results.
- The model can still reword the question. `temperature=0` makes it steady,
  not perfect; compare the printed query with what you typed.
- The score measures relevance, not accuracy.
- Nothing is filtered. All ten results are printed, including the weak ones.
