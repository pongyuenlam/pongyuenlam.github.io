# ReAct05 — the reusable agent has no memory

The same `perform_task(task)` agent called twice: first "When did Mark launch
Muse", then "Is it available in Hong Kong yet?". The second call cannot tell
what "it" is, because every call starts with a fresh prompt.

## Files

- `ReAct05.py` — the agent plus two calls
- `pyproject.toml` — the package list (`openai`, `tavily-python`, `python-dotenv`)
- `README.md` — this file

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with two lines:

   ```
   DEEPSEEK_API_KEY=your-deepseek-key
   TAVILY_API_KEY=your-tavily-key
   ```

   DeepSeek key: https://platform.deepseek.com/api_keys
   Tavily key (free tier): https://app.tavily.com/

3. In the Terminal, run:

   ```
   uv sync
   uv run ReAct05.py
   ```

   `uv sync` is needed only the first time.

## What to watch for

Task 1 answers with a date. Task 2 searches blindly, then honestly asks what
"it" refers to. To give the agent memory, carry the context yourself:

```python
answer1 = perform_task("When did Mark launch Muse")
perform_task(f"Context: {answer1} Is it available in Hong Kong yet?")
```
