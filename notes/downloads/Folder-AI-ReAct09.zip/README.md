# ReAct09 — read a web page and print each sentence

Version 8 of our agent learned to cut a block of text into sentences. Version
9 takes the next step: it fetches a real web page and cuts that page into
sentences.

Two tools do the work:

- `requests` downloads the page.
- `BeautifulSoup` (from `beautifulsoup4`) turns the HTML into something we can
  search, so we can pull out headings, paragraphs and list items.

Then the sentence rule from version 8 does the rest:

    sentences.extend(re.split(r"(?<=[.!?])\s+", block))

## Run it

1. Open the folder in Visual Studio Code.
2. In the Terminal, run these three lines, one at a time:

   ```
   uv python pin 3.12.10
   uv sync
   uv run ReAct09.py
   ```

The `uv sync` step installs `requests` and `beautifulsoup4`, so you need an
internet connection. No API key is needed.

## What to look at

- The first line prints how many sentences were found and which page was read.
- Each following line is one sentence, with a number in front.
- The first sentences are navigation labels (Home, Biography, Research ...),
  because those are list items in the page menu.
- Then come the heading, the tagline and the biography paragraph.
- Try changing `url` to another page and run again.

## Limitations

- The program reads one page and stops. It does not follow links.
- A page built by JavaScript may return almost no text, because the text is not
  in the HTML that `requests` downloads.
- Navigation labels and footers are treated as sentences, exactly like real
  prose.
- Please keep the `User-Agent` header: it tells the website who is visiting.
