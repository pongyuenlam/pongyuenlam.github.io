# Read a web page with requests + BeautifulSoup and print each sentence.
# No AI model here: this is the "reading" step an agent needs before it can use a web page.
import re
import requests
from bs4 import BeautifulSoup

url = "https://pongyuenlam.github.io/"
USER_AGENT = "ReAct09-class-demo"   # tells the website who is visiting

# 1) Download the page, then let BeautifulSoup turn the HTML into something we can search
response = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=10)
soup = BeautifulSoup(response.text, "html.parser")

# 2) Take the text of each block: headings, paragraphs and list items
blocks = []
for element in soup.find_all(["h1", "h2", "h3", "p", "li"]):
    text = element.get_text(" ", strip=True)      # " " joins the text of links inside the block
    text = re.sub(r"\s+", " ", text)              # turn line breaks and extra spaces into one space
    if text:
        blocks.append(text)

# 3) Split each block into sentences: after . ! or ? followed by a space
sentences = []
for block in blocks:
    sentences.extend(re.split(r"(?<=[.!?])\s+", block))

# 4) Print each sentence with a number
print(f"=== {len(sentences)} sentences from {url} ===")
for number, sentence in enumerate(sentences, start=1):
    print(f"{number}. {sentence}")
