# https://pypi.org/project/beautifulsoup4/
import requests
from bs4 import BeautifulSoup
def scrape_webpage(url: str, file_path: str) -> str:
    """
    Fetch a webpage and save its visible text content into a .txt file.

    Args:
        url (str): The webpage URL to scrape.
        file_path (str): Destination path for the .txt file.

    Returns:
        str: The file path that was written.
    """
    response = requests.get(url, timeout=10)
    soup = BeautifulSoup(response.text, "html.parser")
    text = soup.get_text(separator="\n", strip=True)

    with open(file_path, "w", encoding="utf-8") as file:
        file.write(text)
    return file_path

result = scrape_webpage(
    "https://pongyuenlam.github.io/biography.html",
    "tool05_scraper.txt",
)
print(result)

with open(result, "r", encoding="utf-8") as file:
    contents = file.read()
    print(contents)
