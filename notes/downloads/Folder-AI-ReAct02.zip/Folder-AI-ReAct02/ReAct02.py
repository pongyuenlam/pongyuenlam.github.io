# "Reason only" (Chain-of-Thought): NO tool and NO loop.
# The model can only THINK step by step and answer from its own memory.
# Nothing is checked against the real world, so the answer may be wrong (hallucination).
# Compare the result with react03.py (Reason + Act), which searches the web with Tavily.
import os
from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()

client = OpenAI(
    api_key=os.environ.get('DEEPSEEK_API_KEY'),
    base_url="https://api.deepseek.com")

def ask(prompt):
    """Send one prompt to the model and return its text reply."""
    response = client.chat.completions.create(
        model="deepseek-flash",
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content

task = ("When did Mark launch Muse")

# ---- THINK only (Reasoning) — no Action, no Observation ----
prompt = f"""Task: {task}
You have NO tools. Think step-by-step using only what you already know,
then end with one line: Answer: <your answer>"""
reply = ask(prompt)
print("=== Thought (reasoning trace, no tools) ===")
print(reply)
