# ReAct02 — reason only, no tools

The model is asked "When did Mark launch Muse" and may only think step-by-step
from memory. No tool, no observation — nothing checks the answer. Compare the
result with ReAct01 (think, act, observe) to see what a tool adds.

## Files

- `ReAct02.py` — the whole experiment in one file
- `pyproject.toml` — the package list (`openai`, `python-dotenv`)
- `README.md` — this file

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with one line:

   ```
   DEEPSEEK_API_KEY=your-key-here
   ```

   Get a key from the DeepSeek console: https://platform.deepseek.com/api_keys

3. In the Terminal, run:

   ```
   uv sync
   uv run ReAct02.py
   ```

   `uv sync` is needed only the first time. It installs nothing outside this
   project.

## Expected output

One printed block: the reasoning trace, ending with a line that begins
`Answer:`. The answer may be "I don't know" — or a confident guess. Run it a
few times, and try changing the task to a question with a well-known answer,
then to one about a small local company. The contrast is the lesson.
