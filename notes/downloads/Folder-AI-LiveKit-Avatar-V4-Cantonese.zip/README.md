# Run the LiveKit + Synthesia Avatar (V4, Cantonese) on your own computer

A talking AI avatar that lives inside a real web page — and speaks Cantonese
(Hong Kong Cantonese). LiveKit handles the conversation pipeline (microphone ->
speech-to-text -> LLM -> text-to-speech -> avatar), and Synthesia renders a
photorealistic face whose lips match the audio.

This is the Cantonese version: you ask Lin a question in Cantonese, she answers
in colloquial Hong Kong Cantonese with a Cantonese voice, and the page still
scrolls to the part she is talking about. Her knowledge file `FAQs.txt` stays in
English — the LLM translates it on the fly.

For the full explanation of how it works, read the
[online AI note](https://pongyuenlam.github.io/notes/ai-note28.html).

---

## 1. What you need

- A Mac, Windows, or Linux computer.
- The `uv` Python package manager.
  - On a Mac with [Homebrew](https://pongyuenlam.github.io/notes/ai-note18.html):
    run `brew install uv`.
  - Otherwise, see the [uv install guide](https://docs.astral.sh/uv/getting-started/installation/).
- A free [LiveKit Cloud](https://cloud.livekit.io/) account (the **Build** plan
  is enough).
- A [Synthesia](https://www.synthesia.io/) account with at least one avatar
  created there (the free plan lets you try).
- Your LiveKit and Synthesia credentials (see next section). No extra account is
  needed for the Cantonese ears and voice: both run through LiveKit Inference.

## 2. Get your credentials

### LiveKit

1. Sign up at [cloud.livekit.io](https://cloud.livekit.io/).
2. Click **Projects** -> **Create Project**, open the project, and go to
   **Keys**.
3. Copy these three values:
   - `LIVEKIT_URL` — looks like `wss://your-project.livekit.cloud`
   - `LIVEKIT_API_KEY` — a short string like `APIxxxxxxxxxxxxx`
   - `LIVEKIT_API_SECRET` — a long string, shown only once

### Synthesia

1. Sign in at [app.synthesia.io](https://app.synthesia.io/).
2. Go to **Avatars**, pick or create an avatar, open it, and copy the UUID from
   the URL (e.g. `8788bef1-8020-46e0-a8f4-510ea9989b25`). That is
   `SYNTHESIA_AVATAR_ID`.
3. Go to **API Keys** and create a key. That is `SYNTHESIA_API_KEY`.

## 3. Files in this zip

- `agent.py` — the voice agent and avatar engine (Cantonese ears + Cantonese voice)
- `server.py` — the web server that serves the browser page
- `index.html` — the restaurant web page the avatar can scroll
- `FAQs.txt` — the avatar's knowledge base, in English (edit this!)
- `pyproject.toml` — the Python project setup
- `README.md` — this file

## 4. Create your `.env` file

In the project folder, create a file named exactly `.env` with these five lines
(put your real values after the `=` signs):

```
LIVEKIT_URL=wss://your-project.livekit.cloud
LIVEKIT_API_KEY=APIxxxxxxxxxxxxx
LIVEKIT_API_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SYNTHESIA_API_KEY=syn_xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SYNTHESIA_AVATAR_ID=8788bef1-8020-46e0-a8f4-510ea9989b25
```

> **Important:** never upload `.env` to GitHub or any public site. It contains
> your live credentials.

## 5. Install dependencies (only the first time)

Open the folder in VS Code, and in the Terminal run:

```
uv sync
```

This installs Python 3.13 and every package the program needs. You only run
this once.

## 6. Run the program — two terminals

The avatar uses **two processes at the same time**, so you need two Terminal
windows.

### Terminal 1 — the voice agent + avatar engine

```
uv run agent.py dev
```

### Terminal 2 — the web server for the browser page

```
uv run server.py
```

After the first time you only need these two commands (not `uv sync` again).

## 7. Open the page in your browser

With both terminals running, open:

[http://127.0.0.1:8080](http://127.0.0.1:8080)

You will see the YouFantasy restaurant page, with the avatar widget in the
bottom-right corner. Click **Start**, allow the microphone permission, and wait
a few seconds while the agent and avatar join the room. Then ask a question in
Cantonese, for example:

- 「你哋幾點開門？」 (When do you open?)
- 「你哋喺邊度？」 (Where are you?)

Watch the page: as Lin answers in Cantonese, it scrolls to the matching section
and draws a gold ring around it.

## 8. Change what the avatar knows

Open `FAQs.txt` in a text editor and add or edit your questions and answers —
in English. Save the file, refresh the browser page, and start a new call. Lin
will use the updated knowledge, translated into Cantonese as she speaks. No
restart of the terminals is needed.

## 9. Common problems

| Symptom | What to do |
| --- | --- |
| `ModuleNotFoundError` or missing package | Run `uv sync` again. |
| Error about `.env` | Make sure the file is named exactly `.env` (starts with a dot) and sits in the same folder as `agent.py`. |
| Avatar never appears | Check that your LiveKit URL, key and secret are correct, and that the Synthesia API key and avatar ID are correct. |
| Avatar appears but does not answer | Check the Synthesia API key is valid and the avatar ID matches an avatar in your Synthesia account. |
| Lin answers in English or Putonghua | Check that `agent.py` sets `language="yue"` on the STT and TTS lines, and that the prompt tells her to reply in Cantonese. |
| The voice sounds wrong | Try another Inworld Chinese voice: change `VOICE_ID` to `Xiaoyin`, `Jing`, or `Yichen` (male). |
| The page is blank | Make sure Terminal 2 (`uv run server.py`) is running, then open `http://127.0.0.1:8080` again. |
| The page does not scroll | Check that the section names in `agent.py` (`hours`, `mains`, `location`) match the `id` attributes in `index.html`. |

## 10. More information

Read the full AI note for a step-by-step explanation of the code:

[How to use LiveKit and Synthesia Avatar with webpage (version 4)-Cantonese?](https://pongyuenlam.github.io/notes/ai-note28.html)
