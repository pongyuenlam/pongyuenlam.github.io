from flask import Flask, render_template, request, jsonify
app = Flask(__name__)
@app.route("/")
def index():
    return render_template("index.html")
@app.route("/greet", methods=["POST"])
def greet():
    data = request.get_json()
    user_name = data.get("user_name", "")
    return jsonify({"greeting": f"Hello {user_name}"})
