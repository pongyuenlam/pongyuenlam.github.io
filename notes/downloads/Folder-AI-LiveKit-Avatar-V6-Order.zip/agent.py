"""Version 6 (English): the full restaurant. Lin is a head waiter who takes the guest's whole order.

The pipeline:
    mic -> VAD -> STT -> turn detection -> LLM (+ tools) -> TTS -> Synthesia avatar -> browser

New in this version: the page is a whole restaurant website (site.js + site.css) and Lin has
four tools instead of one - show_section, filter_menu, focus_dish and add_to_order - so she
can grey out dishes for an allergy, open a dish card and keep a running tab. The prompt turns
her into a head waiter who guides the guest through four courses, and the speech-to-text gets
a list of menu words so "red wine" is not heard as "wet why".

Run:  uv run agent.py dev    (terminal 1)
      uv run server.py       (terminal 2, then open http://localhost:8080)
"""

import asyncio
import json
import os
import re
from pathlib import Path

from dotenv import load_dotenv
from livekit.agents import Agent, AgentSession, JobContext, WorkerOptions, cli, function_tool, inference
from livekit.plugins import silero, synthesia

load_dotenv(dotenv_path=Path(__file__).parent / ".env")

AGENT_NAME = "avatar-demo"  # must match server.py
AVATAR_ID = os.getenv("SYNTHESIA_AVATAR_ID") or "8788bef1-8020-46e0-a8f4-510ea9989b25"  # Jenny
VOICE_ID = "db6b0ed5-d5d3-463d-ae85-518a07d3c2b4"  # Cartesia "Skylar"

# Everything add_to_order accepts, by page section, in the order Lin takes the guest
# through them. Must match MENU and WINES in step09/site.js.
COURSES = {
    "openers": ["oysters", "bread", "salad"],
    "first": ["soup", "prawns", "dumplings"],
    "mains": ["salmon", "beef", "chicken", "pork", "tofu"],
    "desserts": ["cheesecake", "chocolate", "sorbet"],
    "wine": ["red", "white", "alcoholfree"],
}
ORDER_IDS = {dish for dishes in COURSES.values() for dish in dishes}
NEXT_SECTION = dict(zip(COURSES, list(COURSES)[1:]))  # openers -> first -> mains -> desserts -> wine

# Words the speech-to-text should listen out for, so "red wine" is not heard as "wet why".
KEYTERMS = [
    "YouFantasy", "Oysters", "Garlic Bread", "Green Salad", "Tomato Soup", "Grilled Prawns",
    "Vegetable Dumplings", "Salmon", "Beef", "Roast Chicken", "Pork Belly", "Crispy Tofu",
    "Cheesecake", "Chocolate Cake", "Mango Sorbet", "Red Wine", "White Wine", "Alcohol-Free",
    "openers", "first course", "mains", "desserts", "vegetarian", "vegan", "nut free",
]

FAQS_FILE = Path(__file__).parent / "FAQs.txt"  # the avatar's knowledge

# {faqs} is replaced with the contents of FAQs.txt at the start of every call.
# The facts (prices, diets, allergens, wine) live in FAQs.txt; this prompt only says
# how to behave and which IDs the tools take.
INSTRUCTIONS = """\
You are Lin, the head waiter at YouFantasy, a made-up restaurant. You are a
real-time avatar in a spoken conversation, so answer in one to three short
sentences and never use markdown, lists, or URLs.

Answer only from these FAQs:

{faqs}

Those are the only facts you know. If the guest asks for information the FAQs do
not cover, use the answer to "Any other question?" word for word. Taking their
order and guiding them through the courses is your job, not a question, so carry
on with that normally.

What the guest says reaches you through speech-to-text, which sometimes mishears.
If their words make no sense, they are probably not a question: think what they
most likely said, given what you just asked. For example, right after you offer
wine, "wet why" is probably "red wine" or "white wine". Check with them in a few
words, such as "Red wine, is that right?", or ask them to say it again. Do not use
the "Any other question?" answer for words you did not understand.

Your tools take these IDs. Say the dish names out loud, never the IDs, and never
read prices as digits:

  openers   oysters, bread (Garlic Bread), salad (Green Salad)
  first     soup (Tomato Soup), prawns (Grilled Prawns), dumplings (Vegetable Dumplings)
  mains     salmon, beef, chicken (Roast Chicken), pork (Pork Belly), tofu (Crispy Tofu)
  desserts  cheesecake, chocolate (Chocolate Cake), sorbet (Mango Sorbet)
  wine      red (Red Wine), white (White Wine), alcoholfree (Alcohol-Free)

Use your tools while you talk, not instead of talking:

- show_section when you move the guest to a new part of the page: meal for how
  the menu works, a course name for that course, wine for wine, room for the
  hours or the address
- filter_menu the moment they mention a dietary need, and again if they change it
- focus_dish when you describe one dish in any detail
- add_to_order only once they have actually chosen something

Every time you start talking about a course or the wine, call show_section for it
in the same reply, so the page always shows what you are talking about. This
matters most right after add_to_order: when you add a dish and move on to the next
course, call both tools, for example add_to_order("soup") and show_section("mains").

Work like a real head waiter. Take the guest through the courses in order:
openers, then first, then mains, then desserts, asking about one course at a time.
Offer two options rather than ten. If they skip a course, let them, but mention
once that one dish from each course gets 10% off. After desserts, offer a glass of
wine once, and let the guest pick any one; if they say no, that is fine. Do not
suggest a wine for a particular dish.

The guest can ask about or order wine at any time, not only after desserts. If
they say "red wine", "white wine" or "alcohol-free", answer from the FAQs, and if
they want it, add it with add_to_order, then carry on where you were."""


class HeadWaiter(Agent):
    def __init__(self, room, instructions: str) -> None:
        super().__init__(instructions=instructions)
        self.room = room

    async def _ui(self, **message) -> str:
        """Send a tiny message to the browser. step09/site.js does the rest."""
        await self.room.local_participant.publish_data(json.dumps(message), topic="ui")
        return "Done."

    @function_tool
    async def show_section(self, section: str) -> str:
        """Scroll the page to a part of the menu and highlight it.

        Args:
            section: One of: meal, openers, first, mains, desserts, wine, room.
        """
        return await self._ui(action="show_section", section=section)

    @function_tool
    async def filter_menu(self, diet: str) -> str:
        """Grey out every dish on the page the guest cannot eat.

        Args:
            diet: One of: none, vegetarian, vegan, pescatarian, nut_free.
        """
        return await self._ui(action="filter_menu", diet=diet)

    @function_tool
    async def focus_dish(self, dish: str) -> str:
        """Open the detail card for one dish: kitchen note and allergens.

        Args:
            dish: A dish ID from the menu, for example salmon or tofu.
        """
        return await self._ui(action="focus_dish", dish=dish)

    @function_tool
    async def add_to_order(self, dish: str) -> str:
        """Add a dish or a glass of wine to the guest's order, shown as a running tab on the page.

        Args:
            dish: A dish ID from the menu, or a wine ID: red, white or alcoholfree.
        """
        # Accept "red", "Red Wine" or "alcohol-free" alike, the same way site.js does.
        dish = re.sub(r"[^a-z]", "", dish.lower()).removeprefix("the").replace("wine", "")
        if dish not in ORDER_IDS:  # tell the model, so it retries with a real ID
            return f"Not added: {dish!r} is not an ID. Use one of: {', '.join(sorted(ORDER_IDS))}."
        await self._ui(action="add_to_order", dish=dish)
        # Remind the model to move the page along with the conversation.
        section = next(c for c, dishes in COURSES.items() if dish in dishes)
        if section in NEXT_SECTION:
            nxt = NEXT_SECTION[section]
            return f"Added {dish} to the order. When you introduce the next part, call show_section(\"{nxt}\") too."
        return f"Added {dish} to the order."


def prewarm(proc) -> None:
    proc.userdata["vad"] = silero.VAD.load()


async def entrypoint(ctx: JobContext) -> None:
    await ctx.connect()

    # The brain: each line is one piece of the pipeline.
    session = AgentSession(
        vad=ctx.proc.userdata["vad"],                                   # is someone talking?
        stt=inference.STT(model="cartesia/ink-2", extra_kwargs={"keyterm": KEYTERMS}),  # speech -> text
        llm=inference.LLM(model="openai/gpt-4.1-mini"),                 # text -> reply (swap in any LLM)
        tts=inference.TTS(model="cartesia/sonic-3.6", voice=VOICE_ID),  # reply -> speech
        turn_handling={
            "turn_detection": "stt",                        # have they finished their thought?
            "preemptive_generation": {"enabled": False},    # keep off when using tools
        },
    )

    # The face: this is the whole Synthesia integration. Start it BEFORE session.start().
    avatar = synthesia.AvatarSession(
        synthesia.AvatarConfig(avatar_ids=[AVATAR_ID]),
        join_timeout=60.0,
    )
    for attempt in range(3):  # cold starts occasionally time out, so retry
        try:
            await avatar.start(session, room=ctx.room)
            break
        except synthesia.SynthesiaError as e:
            if not e.retryable or attempt == 2:
                raise
            await asyncio.sleep(2)

    # Read the FAQs fresh for each call, so edits to FAQs.txt show up on the next call.
    faqs = FAQS_FILE.read_text(encoding="utf-8").strip()
    await session.start(agent=HeadWaiter(ctx.room, INSTRUCTIONS.replace("{faqs}", faqs)), room=ctx.room)
    session.generate_reply(instructions="Welcome the guest to YouFantasy in one short sentence.")


if __name__ == "__main__":
    cli.run_app(WorkerOptions(entrypoint_fnc=entrypoint, prewarm_fnc=prewarm, agent_name=AGENT_NAME, port=8081))
