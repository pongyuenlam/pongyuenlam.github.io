/* YouFantasy: the restaurant website.
 *
 * This file knows nothing about avatars, LiveKit or Synthesia. It builds the
 * page and exposes one global, SITE, with one method per tool the agent has:
 *
 *   SITE.show_section({ section })
 *   SITE.filter_menu({ diet })
 *   SITE.focus_dish({ dish })
 *   SITE.add_to_order({ dish })
 *
 * index.html just forwards tool calls into it. Everything here also works on
 * its own, so you can click through the site with the agent switched off.
 */

// ---------------------------------------------------------------- the menu --

// kind: meat | seafood | vegetarian | vegan     nuts: contains nuts
const MENU = [
  { id: 'openers', label: 'Openers', kicker: 'To begin', dishes: [
    { id: 'oysters', name: 'Oysters', note: 'Fresh lemon, shallot vinegar', price: 18,
      kind: 'seafood', nuts: false, allergens: 'Shellfish', from: 'Half a dozen, opened to order' },
    { id: 'bread', name: 'Garlic Bread', note: 'Butter, garlic, parsley', price: 9,
      kind: 'vegetarian', nuts: false, allergens: 'Gluten, dairy', from: 'Baked fresh every evening' },
    { id: 'salad', name: 'Green Salad', note: 'Mixed leaves, walnuts, lemon dressing', price: 12,
      kind: 'vegan', nuts: true, allergens: 'Nuts (walnuts)', from: 'Leaves picked this morning' },
  ]},
  { id: 'first', label: 'First Courses', kicker: 'Before the main', dishes: [
    { id: 'soup', name: 'Tomato Soup', note: 'Roasted tomato, basil, olive oil', price: 14,
      kind: 'vegan', nuts: false, from: 'Made fresh each day' },
    { id: 'prawns', name: 'Grilled Prawns', note: 'Garlic, chili, lime', price: 22,
      kind: 'seafood', nuts: false, allergens: 'Shellfish', from: 'Grilled over charcoal' },
    { id: 'dumplings', name: 'Vegetable Dumplings', note: 'Cabbage, mushroom, ginger, soy dip', price: 16,
      kind: 'vegetarian', nuts: false, allergens: 'Gluten, soy, egg', from: 'Folded by hand' },
  ]},
  { id: 'mains', label: 'Mains', kicker: 'The centre of the meal', dishes: [
    { id: 'salmon', name: 'Salmon', note: 'Crispy skin, green beans, lemon butter', price: 36,
      kind: 'seafood', nuts: false, allergens: 'Fish, dairy', from: 'Pan fried to order' },
    { id: 'beef', name: 'Beef', note: 'Slow cooked beef, mashed potato, gravy', price: 46,
      kind: 'meat', nuts: false, allergens: 'Dairy', from: 'Cooked slowly for twelve hours' },
    { id: 'chicken', name: 'Roast Chicken', note: 'Herbs, roast potatoes, garlic', price: 32,
      kind: 'meat', nuts: false, from: 'Free range, roasted whole' },
    { id: 'pork', name: 'Pork Belly', note: 'Crispy skin, apple, mustard', price: 28,
      kind: 'meat', nuts: false, allergens: 'Mustard', from: 'Roasted slowly, then crisped' },
    { id: 'tofu', name: 'Crispy Tofu', note: 'Sesame, spring onion, chili sauce', price: 28,
      kind: 'vegan', nuts: false, allergens: 'Soy, sesame', from: 'Fried until golden' },
  ]},
  { id: 'desserts', label: 'Desserts', kicker: 'To finish', dishes: [
    { id: 'cheesecake', name: 'Cheesecake', note: 'Vanilla, berries, almond biscuit base', price: 14,
      kind: 'vegetarian', nuts: true, allergens: 'Nuts (almonds), dairy, egg, gluten' },
    { id: 'chocolate', name: 'Chocolate Cake', note: 'Dark chocolate, hazelnuts, cream', price: 15,
      kind: 'vegetarian', nuts: true, allergens: 'Nuts (hazelnuts), dairy, egg' },
    { id: 'sorbet', name: 'Mango Sorbet', note: 'Fresh mango, lime', price: 11,
      kind: 'vegan', nuts: false, from: 'Made fresh each day' },
  ]},
];

// Wine is an add-on, one glass at a time: it can go on the order but never counts toward the discount.
const WINES = [
  { id: 'red', name: 'Red Wine', price: 12, note: 'A smooth red wine.' },
  { id: 'white', name: 'White Wine', price: 12, note: 'A fresh white wine.' },
  { id: 'alcoholfree', name: 'Alcohol-Free', price: 8, note: 'A sparkling fruit and tea drink with no alcohol.' },
];

const COURSES = ['openers', 'first', 'mains', 'desserts'];
const DISCOUNT = 0.10;  // 10% off the food when the order has one dish from every course

const DIETS = {
  none:        { label: 'Everything',   ok: () => true },
  vegetarian:  { label: 'Vegetarian',   ok: (d) => d.kind === 'vegetarian' || d.kind === 'vegan' },
  vegan:       { label: 'Vegan',        ok: (d) => d.kind === 'vegan' },
  pescatarian: { label: 'Pescatarian',  ok: (d) => d.kind !== 'meat' },
  nut_free:    { label: 'Nut free',     ok: (d) => !d.nuts },
};

const ALL = MENU.flatMap((s) => s.dishes);
const byId = (id) => ALL.find((d) => d.id === id);
const courseOf = (d) => MENU.find((s) => s.dishes.includes(d))?.id;
const money = (n) => '$' + (n % 1 ? n.toFixed(2) : n.toFixed(0));

// ------------------------------------------------------------------ build --

const tagsOf = (d) => [
  d.kind === 'vegan' ? 'Vegan' : d.kind === 'vegetarian' ? 'Vegetarian' : null,
  d.kind === 'seafood' ? 'Seafood' : null,
  d.allergens ? d.allergens : null,
].filter(Boolean);

document.getElementById('site').innerHTML = `
<nav>
  <div class="mark">You<span>Fantasy</span></div>
  <div class="nav-links">
    ${['meal', 'openers', 'first', 'mains', 'desserts', 'wine', 'room']
      .map((id) => `<a href="#${id}">${id[0].toUpperCase() + id.slice(1)}</a>`).join('')}
  </div>
  <div class="diet-chip"><span id="diet-label"></span><button title="Clear">&times;</button></div>
</nav>

<header>
  <p class="disclaimer">YouFantasy is a fictional restaurant, built to demo a real-time AI avatar.</p>
  <div>
    <p class="kicker">Four courses &middot; Your choice &middot; Since 2016</p>
    <h1>You<em>F</em>antasy</h1>
    <p class="lede">Choose an opener, a first course, a main and a dessert, and we
      take 10% off. Lin, our head waiter, will take you through it.</p>
    <div class="hero-meta"><span>Every day</span><span>9am &ndash; 10pm</span><span>22 seats</span></div>
    <div class="rule"></div>
  </div>
</header>

<section id="meal"><div class="wrap">
  <div class="sec-head"><h2>Build Your Meal</h2><p>One dish from each course</p></div>
  <div class="tasting">
    <ol class="courses">
      ${COURSES.map((id) => MENU.find((s) => s.id === id))
        .map((s) => `<li>${s.label}<small>${s.dishes.map((d) => d.name).join(', ')}</small></li>`).join('')}
    </ol>
    <aside>
      <p class="kicker">Full meal</p>
      <div class="price-big">10% off</div>
      <p>Order one dish from each of the four courses and we take 10% off the food.
         Every course has a vegan choice.</p>
      <p>Wine is optional, from $8 a glass, and is not discounted.</p>
    </aside>
  </div>
</div></section>

${MENU.map((sec) => `
<section id="${sec.id}"><div class="wrap">
  <div class="sec-head">
    <h2>${sec.label}</h2>
    <span class="count" data-count="${sec.id}"></span>
    <p>${sec.kicker}</p>
  </div>
  <div class="dishes">
    ${sec.dishes.map((d) => `
      <div class="dish" data-dish="${d.id}">
        <div>
          <h3>${d.name}</h3>
          <p>${d.note}</p>
          <div class="tags">${tagsOf(d).map((t) => `<span class="tag">${t}</span>`).join('')}</div>
        </div>
        <div class="price">${money(d.price)}</div>
      </div>`).join('')}
  </div>
</div></section>`).join('')}

<section id="wine"><div class="wrap">
  <div class="sec-head"><h2>Wine</h2><p>One glass with your meal</p></div>
  <div class="flights">
    ${WINES.map((f) => `<div class="flight">
      <p class="kicker">By the glass</p><h3>${f.name}</h3><p>${f.note}</p>
      <div class="price">${money(f.price)}</div>
      <button class="btn ghost" data-wine="${f.id}">Add to order</button>
    </div>`).join('')}
  </div>
</div></section>

<section id="room"><div class="wrap">
  <div class="sec-head"><h2>The Room</h2><p>Tat Chee Avenue, Kowloon Tong, Hong Kong</p></div>
  <div class="two-col">
    <div>
      <p>YouFantasy is a twenty-two seat room on Tat Chee Avenue, Kowloon Tong,
         Hong Kong. There is one menu and one kitchen, and the pass is close enough
         that the person who cooked your course is usually the person who sets it down.</p>
      <p>We are open every day from 9am to 10pm.</p>
    </div>
    <ul class="hours">
      <li><b>Every day</b><span>9:00am &ndash; 10:00pm</span></li>
      <li><b>Address</b><span>Tat Chee Avenue, Kowloon Tong</span></li>
    </ul>
  </div>
</div></section>

<footer><div class="wrap" style="display:flex;justify-content:space-between;width:100%">
  <span>YouFantasy &middot; Fictional, for demonstration</span><span>&copy; 2026</span>
</div></footer>

<div id="detail">
  <button class="close">&times;</button>
  <p class="kicker" id="d-kicker"></p>
  <h3 id="d-name"></h3>
  <p id="d-note"></p>
  <div class="price" id="d-price"></div>
  <dl id="d-meta"></dl>
  <button class="btn" id="d-add">Add to order</button>
</div>

<div id="order">
  <p class="kicker">Your order</p>
  <ul class="food"></ul>
  <div class="discount"><span>Full meal, 10% off food</span><b></b></div>
  <ul class="wine"></ul>
  <div class="total"><span>Total</span><b>$0</b></div>
</div>`;

// --------------------------------------------------------------- the API ---

const $ = (s) => document.querySelector(s);
const order = [];

const SITE = {
  /** Scroll to a part of the menu and draw a ring around it. */
  show_section({ section }) {
    const el = document.getElementById(section);
    if (!el) return;
    $('#detail').classList.remove('open');   // moving on, so close any open dish card
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    document.querySelectorAll('.highlight').forEach((h) => h.classList.remove('highlight'));
    el.classList.add('highlight');
  },

  /** Grey out every dish the guest can't eat, and count what's left. */
  filter_menu({ diet }) {
    const rule = DIETS[diet] || DIETS.none;
    document.body.dataset.diet = diet;
    $('#diet-label').textContent = rule.label;

    document.querySelectorAll('.dish').forEach((el) => {
      const ok = rule.ok(byId(el.dataset.dish));
      el.classList.toggle('out', !ok);
      if (ok && diet !== 'none') { el.classList.remove('in'); void el.offsetWidth; el.classList.add('in'); }
    });
    MENU.forEach((sec) => {
      const n = sec.dishes.filter(rule.ok).length;
      $(`[data-count="${sec.id}"]`).textContent = `${n} of ${sec.dishes.length}`;
    });
  },

  /** Open the card for one dish: where it's from, allergens, what to drink. */
  focus_dish({ dish }) {
    const d = byId(dish);
    if (!d) return;
    $('#d-kicker').textContent = MENU.find((s) => s.dishes.includes(d)).label;
    $('#d-name').textContent = d.name;
    $('#d-note').textContent = d.note;
    $('#d-price').textContent = money(d.price);
    $('#d-meta').innerHTML = [
      d.from && ['Kitchen note', d.from],
      d.allergens && ['Allergens', d.allergens],
    ].filter(Boolean).map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('');
    $('#d-add').onclick = () => SITE.add_to_order({ dish });
    SITE.show_section({ section: MENU.find((s) => s.dishes.includes(d)).id });  // first: it closes the card
    $('#detail').classList.add('open');
  },

  /** Add a dish or a glass of wine to the running tab in the corner. */
  add_to_order({ dish }) {
    // Accept "red", "Red Wine" or "alcohol-free" alike.
    const key = String(dish).toLowerCase().replace(/[^a-z]/g, '').replace(/^the|wine/g, '');
    const d = byId(dish) || WINES.find((f) => f.id === key);
    if (d) { order.push(d); renderOrder(); $('#detail').classList.remove('open'); }  // chosen, so close the card
  },
};

function renderOrder() {
  $('#order').classList.toggle('open', order.length > 0);

  // Food first, in course order; then the discount; then wine, which is never discounted.
  // data-i is the item's place in `order`, so the x button removes the right one.
  const row = ({ d, i }) => `
    <li><span>${d.name}</span>
      <span style="display:flex;gap:10px"><b>${money(d.price)}</b>
      <button data-i="${i}">&times;</button></span></li>`;
  const items = order.map((d, i) => ({ d, i }));
  $('#order ul.food').innerHTML = items.filter(({ d }) => courseOf(d))
    .sort((a, b) => COURSES.indexOf(courseOf(a.d)) - COURSES.indexOf(courseOf(b.d)) || a.i - b.i)
    .map(row).join('');
  $('#order ul.wine').innerHTML = items.filter(({ d }) => !courseOf(d)).map(row).join('');

  // One dish from every course takes 10% off the food. Wine is never discounted.
  const food = order.filter(courseOf);
  const fullMeal = COURSES.every((c) => food.some((d) => courseOf(d) === c));
  const discount = fullMeal ? food.reduce((t, d) => t + d.price, 0) * DISCOUNT : 0;
  $('#order .discount').classList.toggle('on', fullMeal);
  $('#order .discount b').textContent = '-' + money(discount);
  $('#order .total b').textContent = money(order.reduce((t, d) => t + d.price, 0) - discount);
}

// ------------------------------------------------------- clicks and keys ---

document.addEventListener('click', (e) => {
  const dish = e.target.closest('.dish');
  if (dish) SITE.focus_dish({ dish: dish.dataset.dish });

  if (e.target.closest('#detail .close')) $('#detail').classList.remove('open');
  if (e.target.closest('.diet-chip button')) SITE.filter_menu({ diet: 'none' });

  const wine = e.target.closest('[data-wine]');
  if (wine) SITE.add_to_order({ dish: wine.dataset.wine });

  const rm = e.target.closest('#order li button');
  if (rm) { order.splice(+rm.dataset.i, 1); renderOrder(); }
});

SITE.filter_menu({ diet: 'none' });
window.SITE = SITE;
