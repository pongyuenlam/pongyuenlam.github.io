# Run the LiveKit + Synthesia Avatar (V6, ordering) on your own computer

Lin is a talking head waiter inside a restaurant website. She answers questions, scrolls the
page, greys out dishes you cannot eat, opens dish cards and takes your whole order.

## Files

| File | What it does |
| --- | --- |
| `agent.py` | The voice agent: mic -> STT -> LLM (with four tools) -> TTS -> Synthesia avatar. |
| `server.py` | Serves `index.html`, `site.js`, `site.css` and hands out LiveKit tokens. |
| `index.html` | A small shell: the avatar widget and the LiveKit connection. |
| `site.js` | The whole restaurant website, with one method per tool (`SITE.show_section`, etc.). |
| `site.css` | The look of that website. |
| `FAQs.txt` | Everything Lin knows: the menu, prices, diets, allergens and wine. |
| `pyproject.toml` | The Python packages. |

## 1. Create your `.env`

Put this file next to `agent.py`, with your own values:

```
LIVEKIT_URL=wss://your-project.livekit.cloud
LIVEKIT_API_KEY=...
LIVEKIT_API_SECRET=...
SYNTHESIA_API_KEY=...
SYNTHESIA_AVATAR_ID=8788bef1-8020-46e0-a8f4-510ea9989b25
```

The first three come from your LiveKit project; the last two from Synthesia.

## 2. Install

```
uv sync
```

## 3. Run, in two terminals

Terminal 1 - the agent and the avatar:

```
uv run agent.py dev
```

Terminal 2 - the web server:

```
uv run server.py
```

Then open http://localhost:8080 and click **Start**.

## What to say

- "What do you recommend?" - she guides you through the courses, one at a time.
- "I am vegan." - the page greys out every dish you cannot eat.
- "Tell me about the beef." - the dish card opens with the kitchen note and allergens.
- "I will have the soup." - the tab in the corner adds Tomato Soup.

One dish from each of the four courses earns 10% off the food. Wine is never discounted.

To change what Lin knows, edit `FAQs.txt` and start a new conversation; the file is read
fresh on every call.
