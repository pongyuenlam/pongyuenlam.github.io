import requests
from dotenv import load_dotenv
from livekit.agents import (
    Agent,
    AgentServer,
    AgentSession,
    JobContext,
    RunContext,
    cli,
    function_tool,
    inference,
)

load_dotenv()


def _geocode(city: str) -> tuple[float, float, str] | None:
    """Resolve a city name to (lat, lon, resolved_label) using Open-Meteo geocoding."""
    r = requests.get(
        "https://geocoding-api.open-meteo.com/v1/search",
        params={"name": city, "count": 1, "language": "en", "format": "json"},
        timeout=10,
    )
    results = r.json().get("results")
    if not results:
        return None
    best = results[0]
    name = best.get("name", city)
    country = best.get("country")
    label = f"{name}, {country}" if country else name
    return best["latitude"], best["longitude"], label


def _ip_location() -> tuple[float, float, str] | None:
    """Resolve lat/lon AND a human-readable city/region label from the caller's IP."""
    try:
        info = requests.get("https://ipinfo.io/json", timeout=10).json()
        lat_str, lon_str = info["loc"].split(",")
        parts = [p for p in (info.get("city"), info.get("region"), info.get("country")) if p]
        label = ", ".join(parts) if parts else "your current location"
        return float(lat_str), float(lon_str), label
    except Exception:
        return None


def _fetch_weather(latitude: float, longitude: float) -> dict:
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "current": "temperature_2m,weather_code,relative_humidity_2m,apparent_temperature",
        "daily": "temperature_2m_max,temperature_2m_min,weather_code",
        "temperature_unit": "celsius",
        "timezone": "auto",
        "forecast_days": 1,
    }
    data = requests.get(
        "https://api.open-meteo.com/v1/forecast",
        params=params,
        timeout=10,
    ).json()
    return data


# WMO weather code -> short English description
_WMO_CODES = {
    0: "clear sky",
    1: "mainly clear", 2: "partly cloudy", 3: "overcast",
    45: "fog", 48: "freezing fog",
    51: "light drizzle", 53: "moderate drizzle", 55: "dense drizzle",
    56: "light freezing drizzle", 57: "dense freezing drizzle",
    61: "slight rain", 63: "moderate rain", 65: "heavy rain",
    66: "light freezing rain", 67: "heavy freezing rain",
    71: "slight snow fall", 73: "moderate snow fall", 75: "heavy snow fall",
    77: "snow grains",
    80: "slight rain showers", 81: "moderate rain showers", 82: "violent rain showers",
    85: "slight snow showers", 86: "heavy snow showers",
    95: "thunderstorm", 96: "thunderstorm with slight hail", 99: "thunderstorm with heavy hail",
}


@function_tool
async def lookup_weather(
    context: RunContext,
    location: str = "",
):
    """
    Look up weather information. If the user mentions a specific city or
    place (e.g. "Tokyo", "Mountain View"), pass it in. Otherwise — when the
    user says "here", "my city", "where I am", or does not name any place —
    call this tool with no location argument. It will automatically detect
    the user's approximate city from their IP address.
    """

    lat = lon = None
    resolved = ""

    if location and location.strip():
        geo = _geocode(location.strip())
        if geo:
            lat, lon, resolved = geo

    if lat is None:
        ip = _ip_location()
        if ip is None:
            return {"error": "Could not detect your location automatically."}
        lat, lon, resolved = ip

    try:
        data = _fetch_weather(lat, lon)
    except Exception as e:
        return {"error": f"Weather service unavailable: {e}"}

    cur = data.get("current", {}) or {}
    daily = data.get("daily", {}) or {}
    code = cur.get("weather_code")
    condition = _WMO_CODES.get(code, f"code {code}") if code is not None else "unknown"

    return {
        "location": resolved,
        "temperature_c": cur.get("temperature_2m"),
        "feels_like_c": cur.get("apparent_temperature"),
        "condition": condition,
        "humidity_percent": cur.get("relative_humidity_2m"),
        "today_high_c": (daily.get("temperature_2m_max") or [None])[0],
        "today_low_c": (daily.get("temperature_2m_min") or [None])[0],
    }


server = AgentServer()


@server.rtc_session()
async def entrypoint(ctx: JobContext):
    session = AgentSession(
        vad=inference.VAD(),
        # any combination of STT, LLM, TTS, or realtime API can be used
        # this example shows LiveKit Inference, a unified API to access different models via LiveKit Cloud
        # to use model provider keys directly, replace with the following:
        # from livekit.plugins import deepgram, openai, cartesia
        # stt=deepgram.STT(model="nova-3"),
        # llm=openai.LLM(model="gpt-4.1-mini"),
        # tts=cartesia.TTS(model="sonic-3", voice="9626c31c-bec5-4cca-baa8-f8ba9e84c8bc"),
        stt=inference.STT("deepgram/nova-3", language="multi"),
        llm=inference.LLM("google/gemma-4-31b-it"),  # low-latency gemma, hosted on LiveKit
        tts=inference.TTS("cartesia/sonic-3", voice="9626c31c-bec5-4cca-baa8-f8ba9e84c8bc"),
    )

    agent = Agent(
        instructions=(
            "You are a friendly voice assistant built by LiveKit. "
            "You can answer weather questions. You do NOT need to ask the "
            "user which city they are in — if they do not name a specific "
            "city, just call lookup_weather() with no arguments and it will "
            "auto-detect their location. Only pass a location when the user "
            "explicitly names one (e.g. 'what's the weather in Tokyo?'). "
            "Never ask 'which city?' — always try to answer directly first."
        ),
        tools=[lookup_weather],
    )

    await session.start(agent=agent, room=ctx.room)
    await session.generate_reply(instructions="greet the user and ask about their day")


if __name__ == "__main__":
    cli.run_app(server)