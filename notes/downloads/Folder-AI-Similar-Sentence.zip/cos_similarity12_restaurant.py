from sentence_transformers import SentenceTransformer
import numpy as np

model = SentenceTransformer('BAAI/bge-m3')

with open('sentences-restaurant.txt', 'r', encoding='utf-8') as f:
    sentences = [line.strip() for line in f.readlines() if line.strip()]

user_question = "What is your address?"

question_embedding = model.encode(user_question.strip().lower())
sentence_embeddings = model.encode([s.lower() for s in sentences])

dot_product = np.dot(sentence_embeddings, question_embedding)
dense_scores = dot_product / (np.linalg.norm(sentence_embeddings, axis=1) * np.linalg.norm(question_embedding))

ranked_indices = np.argsort(dense_scores)[::-1]
i = ranked_indices[0]

if dense_scores[i] > 0.5:
    print(f"Your question is: {user_question}")
    print(f"You can find answer from the sentence number {i}")
    print(f"The sentence is: {sentences[i]}")
else:
    print("no answer")
