# research05 — four tools, search, select, draft, then enhance the draft

Version 5 adds a fourth tool. `search_internet` searches the web and saves the
response in `last_search`. `generate_draft` keeps only the results that pass its
rule: a score of 0.5 or higher, and never Wikipedia. `write_draft` receives one
sentence per kept result and turns them into a draft with numbered endnotes.
`enhance_draft` then reads that draft, always keeps sentence 1, and drops the
sentences that only repeat a figure already given, renumbering the endnotes
that survive. In the demo run, ten results become seven, the seven become a
draft with seven endnotes, and the enhanced draft has five sentences and five
endnotes.

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with two lines:

   ```
   TAVILY_API_KEY=your-tavily-key
   DEEPSEEK_API_KEY=your-deepseek-key
   ```

   A Tavily key is available from the [Tavily dashboard](https://app.tavily.com/home),
   and a DeepSeek key from the [DeepSeek console](https://platform.deepseek.com/api_keys).
3. In the Terminal, run these three lines, one at a time:

   ```
   uv python pin 3.12.10
   uv sync
   uv run research05.py
   ```

This version calls a language model several times, once for each tool it
chooses, so it needs both keys. It takes a few seconds.

## What to look at

- `tavily_search.json` — the raw search response is saved to this file, then
  read back if it is still there. The program deletes it before the run starts,
  so every run makes a fresh search.
- `draft_items` — the third shared variable. `write_draft` fills it with one
  sentence and one link per kept result, and `enhance_draft` reads it.
- `skipped_items` — the fourth shared variable. `enhance_draft` writes down
  every sentence it dropped, and the program prints that list at the end.
- `enumerate(draft_items, start=1)` — the count starts at 1, so the first item
  is sentence 1, not sentence 0.
- `if i != 1 and i not in keep` — sentence 1 is never dropped, and the other
  sentences survive only when the model put their number in `keep`.
- Four `Tool:` blocks on screen — search, select, draft, enhance.

## Try it

- Change `start=1` to `start=0` and see the sentence numbers in the skipped list
  go wrong.
- Delete `i != 1 and` and ask the model to drop sentence 1. The draft now starts
  with a later sentence, renumbered as [1].
- Change the system prompt from "skip a sentence that only repeats a similar
  figure" to "keep every sentence" and compare the two drafts.
- Remove `return_direct=True` from `enhance_draft` and see what the model adds
  after the enhanced draft.

## Limitations

- A draft, not a report: quoted sentences in the order of the results, with
  nothing connecting them.
- The judgement is the model's. Two similar figures can both survive, or a
  useful sentence can be dropped by mistake.
- Copying is not checking: a copied sentence can still be out of date.
- Sentence 1 is always kept, even when a later sentence is better.
- The program prints what was skipped, but it does not put it back.
