import os
import json
from dotenv import load_dotenv
from tavily import TavilyClient
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent

load_dotenv()
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")
tavily_client = TavilyClient(api_key=TAVILY_API_KEY)

last_search = {}
selected_results = []
draft_items = []
skipped_items = []

@tool
def search_internet(query: str):
    """
    Search the internet for up-to-date information about the query
    and return the full Tavily search response.
    """
    global last_search
    if os.path.exists("tavily_search.json"):
        with open("tavily_search.json", "r", encoding="utf-8") as f:
            response = json.load(f)
    else:
        response = tavily_client.search(query, max_results=10)
        with open("tavily_search.json", "w", encoding="utf-8") as f:
            json.dump(response, f, ensure_ascii=False, indent=2)
    last_search = response
    return response

@tool
def generate_draft():
    """
    Go through the results from the latest search_internet call.
    Keep results with a score of 0.5 or higher, but never keep Wikipedia.
    Return the selected results.
    """
    global selected_results
    selected = []
    for r in last_search.get("results", []):
        if r["score"] >= 0.5 and "wikipedia.org" not in r["url"]:
            selected.append(r)

    selected_results = selected
    return {"query": last_search.get("query"), "results": selected}

@tool
def write_draft(sentences: list[str]):
    """
    Write a draft with endnotes from the results of generate_draft.
    sentences: one sentence per result from generate_draft, in the same order.
    Each sentence must be copied exactly from that result's content, and be
    the sentence closest in meaning to the user's query.
    Use an empty string "" for a result that has no complete sentence.
    """
    global draft_items
    draft_items = []
    s = ""
    endnotes = ""
    endnote_num = 1
    for sentence, r in zip(sentences, selected_results):
        if sentence.strip() == "":
            continue  # skip results with no complete sentence
        s = s + sentence + "[" + str(endnote_num) + "]\n"
        endnotes = endnotes + f"[{endnote_num}] {r['url']}\n"
        draft_items.append({"sentence": sentence, "url": r["url"]})
        endnote_num = endnote_num + 1
    s = s + "\nEndnotes:\n" + endnotes
    return s

@tool(return_direct=True)
def enhance_draft(keep: list[int]):
    """
    Write an enhanced draft from the draft made by write_draft.
    keep: the endnote numbers of the sentences to keep. Sentence 1 is always kept.
    Read sentences 2, 3, ... one by one, and keep a sentence only if it adds
    useful new information that the sentences already kept do not give.
    """
    global skipped_items
    skipped_items = []
    s = ""
    endnotes = ""
    endnote_num = 1
    for i, item in enumerate(draft_items, start=1):
        if i != 1 and i not in keep:
            skipped_items.append({"num": i, "sentence": item["sentence"], "url": item["url"]})
            continue  # skip sentences that add little new information
        s = s + item["sentence"] + "[" + str(endnote_num) + "]\n"
        endnotes = endnotes + f"[{endnote_num}] {item['url']}\n"
        endnote_num = endnote_num + 1
    s = s + "\nEndnotes:\n" + endnotes
    return s

model = ChatOpenAI(
    model="deepseek-flash",
    api_key=DEEPSEEK_API_KEY,
    base_url="https://api.deepseek.com",
    temperature=0,
)

agent = create_agent(
    model=model,
    tools=[search_internet, generate_draft, write_draft, enhance_draft],
    system_prompt="""
You are a helpful assistant.
Always call search_internet, using the user's message exactly as the query.
Do not rephrase, shorten, translate, or add anything to it.
Then call generate_draft to select the useful results.
Then go through each sentence in each selected result, pick the one sentence
closest in meaning to the user's query, and copy it exactly.
A complete sentence has a subject and a verb and ends with a full stop;
table rows, headings, menus and fragments are not complete sentences.
If a result has no complete sentence, use an empty string "" for it.
Call write_draft with these sentences in the same order as the results.
Then read the draft from write_draft. Keep sentence 1.
Read the remaining sentences one by one, and keep a sentence only if it adds
useful new information that the sentences already kept do not give.
Skip a sentence that only repeats a similar figure already given.
Keep a sentence that adds a new fact, such as a ranking, a trend,
a breakdown, or an official government source.
Call enhance_draft with the endnote numbers of the sentences to keep.
""",
)

if os.path.exists("tavily_search.json"):
    os.remove("tavily_search.json")  # start each run with a fresh search

prompt = "What is the population of Hong Kong?"
result = agent.invoke({
    "messages": [{"role": "user", "content": prompt}]
})

for message in result["messages"]:
    if message.type == "tool" and message.name in ["write_draft", "enhance_draft"]:
        print(f"Tool: {message.name}\n")
        print(message.content)
    elif message.type == "tool":
        response = json.loads(message.content)
        print(f"Tool: {message.name}")
        print(f"Query: {response['query']}\n")
        for i, r in enumerate(response["results"], start=1):
            print(f"{i}. {r['title']}  (score: {r['score']:.2f})")
            print(f"   {r['url']}")
            print(f"   {r['content'][:200].replace(chr(10), ' ')}...\n")

print("Sentences skipped by enhance_draft:\n")
if skipped_items == []:
    print("None\n")
for item in skipped_items:
    print(f"[{item['num']} in write_draft] {item['sentence']}")
    print(f"   {item['url']}\n")
