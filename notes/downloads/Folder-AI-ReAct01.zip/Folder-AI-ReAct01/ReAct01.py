# Step 1: THINK  -> ask the model to reason step by step (reasoning trace)
# Step 2: ACT    -> append that trace to the prompt and ask "What action should be taken?"
# Step 3: OBSERVE-> run the action (a real tool), feed the result back, get the final answer
import os
import requests
from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()

client = OpenAI(
    api_key=os.environ.get('DEEPSEEK_API_KEY'),
    base_url="https://api.deepseek.com")

def ask(prompt):
    """Send one prompt to the model and return its text reply."""
    response = client.chat.completions.create(
        model="deepseek-flash",
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content

# The only tool (action) our agent can use
def get_hk_temperature():
    """Return the current temperature in Hong Kong from open-meteo.com."""
    params = {"latitude": 22.32, "longitude": 114.17,
              "current": "temperature_2m", "timezone": "auto"}
    data = requests.get("https://api.open-meteo.com/v1/forecast",
                        params=params, timeout=10).json()
    return f"{data['current']['temperature_2m']}°C"

task = "What is the temperature in Hong Kong today?"

# ---- Step 1: THINK (Reasoning) ----
prompt = f"""Task: {task}
Think step-by-step about how to solve this task. Do not answer yet."""
thought = ask(prompt)
print("=== Step 1: Thought (reasoning trace) ===")
print(thought)

# ---- Step 2: ACT — append the reasoning trace to the prompt, then ask for an action ----
prompt = prompt + f"""

Thought: {thought}

You have ONE tool: get_hk_temperature. What action should be taken based on that? Reply with ONLY: get_hk_temperature or none"""
action = ask(prompt).strip()
print("=== Step 2: Action chosen by the model ===")
print(action)

# ---- Step 3: OBSERVE — our Python code (not the model) runs the tool ----
if "get_hk_temperature" in action:
    observation = get_hk_temperature()
else:
    observation = "No action taken."
print("=== Step 3: Observation from the real world ===")
print(observation)

# ---- Final answer: the model reasons again, now grounded in the observation ----
prompt = prompt + f"""

Action: {action}
Observation: {observation}

Now give the final answer to the task in one sentence."""
print("=== Final Answer ===")
print(ask(prompt))
