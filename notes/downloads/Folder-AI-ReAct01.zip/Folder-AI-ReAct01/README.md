# ReAct01 — think, act, observe

The smallest ReAct agent: the model reasons about a task, chooses one tool,
Python runs the tool (the current temperature in Hong Kong, from Open-Meteo),
and the model writes the final answer grounded in the real result.

## Files

- `ReAct01.py` — the whole agent in one file
- `pyproject.toml` — the package list (`openai`, `requests`, `python-dotenv`)
- `README.md` — this file

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with one line:

   ```
   DEEPSEEK_API_KEY=your-key-here
   ```

   Get a key from the DeepSeek console: https://platform.deepseek.com/api_keys

3. In the Terminal, run:

   ```
   uv sync
   uv run ReAct01.py
   ```

   `uv sync` is needed only the first time. It installs nothing outside this
   project.

## Expected output

Four printed blocks, in order:

1. `=== Step 1: Thought (reasoning trace) ===` — the model's written reasoning
2. `=== Step 2: Action chosen by the model ===` — `get_hk_temperature`
3. `=== Step 3: Observation from the real world ===` — for example `26.8°C`
4. `=== Final Answer ===` — one sentence that uses the real number

If Step 2 prints `none`, the model did not pick the tool; run again, or check
that the tool name in the prompt matches the function name exactly.
