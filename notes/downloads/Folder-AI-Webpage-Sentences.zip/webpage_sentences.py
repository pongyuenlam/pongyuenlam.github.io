import re

import requests
from bs4 import BeautifulSoup

url = "https://www.panadol.com/en-gb/adult-symptoms/headache/"
headers = {"User-Agent": "Mozilla/5.0 (compatible; SkillBot/1.0)"}
resp = requests.get(url, headers=headers, timeout=15)
resp.raise_for_status()
resp.encoding = resp.apparent_encoding

soup = BeautifulSoup(resp.text, "html.parser")
for tag in soup(["script", "style", "noscript", "nav", "footer"]):
    tag.decompose()

lines = [" ".join(tag.get_text(" ").split()) for tag in soup.find_all(["h1", "h2", "h3", "p", "li"])]
lines = [line for line in lines if line != ""]

sentences = []
for line in lines:
    for sentence in re.split(r"(?<=[.!?])\s+(?=[A-Z])", line):
        sentences.append(sentence)
lines = sentences

with open("panadol.txt", "w", encoding="utf-8") as outfile:
    for line in lines:
        outfile.write(line + "\n")

print(f"Saved {len(lines)} sentences to panadol.txt")
print("The first three sentences:")
for line in lines[:3]:
    print(line)
