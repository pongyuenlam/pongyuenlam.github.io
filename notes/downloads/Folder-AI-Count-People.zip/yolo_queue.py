from ultralytics.solutions import ObjectCounter
import cv2
model_path = "yolo26n.pt"
video_path = "queue-management-demo.mp4"
# Get video properties: width, height, FPS (frame/second)
cap = cv2.VideoCapture(video_path)
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = cap.get(cv2.CAP_PROP_FPS)
region_points = [(width-400, 300), (width-400, height), (width-350, height), (width-350, 300)]
# Initialize ObjectCounter 
counter = ObjectCounter(
    model=model_path,
    region=region_points,
    show=True,
    show_labels = False,
    show_conf = False,
    show_in=True,
    show_out=False
)
# Define the codec and create VideoWriter object to save the output video
fourcc = cv2.VideoWriter_fourcc(*'avc1')  # H.264, plays on Mac
out = cv2.VideoWriter('result_queue.mp4', fourcc, fps, (width, height))
if not out.isOpened():  # avc1 not available (e.g. Windows), use mp4v instead
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter('result_queue.mp4', fourcc, fps, (width, height))
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    results = counter(frame)
    annotated_frame = results.plot_im
    # Write the annotated frame to the output video
    out.write(annotated_frame)
    key = cv2.waitKey(1)
    if key == ord('q') or key == ord('Q'):
        break
cap.release()
out.release()
cv2.destroyAllWindows()
print("In count:", results.in_count)

