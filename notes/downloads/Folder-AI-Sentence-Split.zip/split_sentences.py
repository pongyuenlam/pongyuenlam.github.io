import re

with open("my_text.txt", encoding="utf-8") as f:
    lines = f.readlines()

sentences = []
for line in lines:
    for sentence in re.split(r"(?<=[.!?])\s+(?=[A-Z])", line):
        sentences.append(sentence)
lines = sentences

for sentence in lines:
    print(sentence.strip())
