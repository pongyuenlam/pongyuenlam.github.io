# research03 — two tools, search then filter

Version 3 gives the agent a second tool. `search_internet` searches the web as
before and saves the response in `last_search`. `generate_draft` then reads that
saved response and keeps only the results that pass its rule: a score of 0.5 or
higher, and never Wikipedia. In the demo run, ten results become seven.

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with two lines:

   ```
   TAVILY_API_KEY=your-tavily-key
   DEEPSEEK_API_KEY=your-deepseek-key
   ```

   A Tavily key is available from the [Tavily dashboard](https://app.tavily.com/home),
   and a DeepSeek key from the [DeepSeek console](https://platform.deepseek.com/api_keys).
3. In the Terminal, run these three lines, one at a time:

   ```
   uv python pin 3.12.10
   uv sync
   uv run research03.py
   ```

This version calls a language model once, so it needs both keys. It takes a
few seconds.

## What to look at

- `last_search` — a variable outside both tools. The search writes to it and the
  filter reads from it, which is how one tool can see another tool's work.
- `global last_search` — tells Python to change the shared variable rather than
  make a local copy.
- `@tool(return_direct=True)` — now on `generate_draft`, not on the search, so
  the run stops after filtering, not after searching.
- The `if` line — two conditions joined by `and`: the score must reach 0.5, and
  the URL must not contain `wikipedia.org`.
- Two `Tool:` blocks on screen — the search prints ten results, then the filter
  prints the seven that survived.

## Try it

- Change `0.5` to `0.9` and run it again. Only the top few results remain.
- Remove the Wikipedia check and watch that entry come back with a score of
  0.92.
- Change `then call generate_draft` in the system prompt to `call
  generate_draft first`. The order of the two `Tool:` blocks may change, which
  shows that the prompt, not the tools list, sets the order.

## Limitations

- The rule is coarse. A useful page scoring 0.49 is thrown away, and a page that
  passes can still be wrong or out of date.
- The model still has to follow the order. Check the printed output rather than
  assuming it.
- `last_search` holds only the most recent search, so a second search replaces
  the first without warning.
- Nothing has been read yet. Choosing among the seven is the next version's job.
