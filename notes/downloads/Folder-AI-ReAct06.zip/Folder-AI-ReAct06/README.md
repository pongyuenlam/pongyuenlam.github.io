# ReAct06 — an agent with long-term memory

Version 5 asked two questions in a row and the follow-up failed, because the
agent forgot the first task. This version adds `memory.json`: every finished
answer is saved to the file and loaded into the next prompt, so
"Is it available in Hong Kong yet?" knows what "it" refers to.

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with two lines:

   ```
   DEEPSEEK_API_KEY=your-deepseek-key
   TAVILY_API_KEY=your-tavily-key
   ```

   Keys: [DeepSeek console](https://platform.deepseek.com/api_keys) and
   [Tavily](https://app.tavily.com/) (both have free starting credit).
3. In the Terminal, run:

   ```
   uv sync
   uv run ReAct06.py
   ```

## What to look at

- The script wipes `memory.json` at the start of every run, so each run
  begins with an empty memory.
- After the run, open `memory.json` in the folder: both answers are saved
  there, with dates.
- Try a third `perform_task(...)` of your own at the bottom of the file and
  watch the memory section of the prompt grow.
