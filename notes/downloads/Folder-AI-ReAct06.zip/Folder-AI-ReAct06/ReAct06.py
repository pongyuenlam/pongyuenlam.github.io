# Same ReAct idea as react01.py, but this task needs MORE THAN ONE action,
# so we repeat Think -> Act -> Observe in a loop until the model says "finish".
# Step 1: THINK  -> ask the model to reason about what to do next
# Step 2: ACT    -> ask for ONE action: search[...] or finish[...]
# Step 3: OBSERVE-> run the Tavily web search (a real tool), add the result to the prompt, loop again
# MEMORY: short-term = the growing `prompt` string inside ONE task.
#         long-term  = memory.json, which keeps answers AFTER a task ends,
#                      so the next task in this run can use them.
# Each run starts with an empty memory.json (see the bottom of this file).
import os
import re
import json
from datetime import datetime
from tavily import TavilyClient
from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()

MEMORY_FILE = "memory.json"    # long-term memory lives in this file
today = datetime.now().strftime('%Y-%m-%d')

client = OpenAI(
    api_key=os.environ.get('DEEPSEEK_API_KEY'),
    base_url="https://api.deepseek.com")
tavily = TavilyClient(api_key=os.environ.get('TAVILY_API_KEY'))

def ask(prompt, stop=None):
    """Send one prompt to the model and return its text reply."""
    response = client.chat.completions.create(
        model="deepseek-flash",
        messages=[{"role": "user", "content": prompt}],
        stop=stop,   # stop writing when this text appears
    )
    return response.choices[0].message.content

# The only tool (action) our agent can use
def search_tavily(query):
    """Return the top web results from Tavily (title, url, short content)."""
    results = tavily.search(query=query, max_results=3)["results"]
    if not results:
        return f"No web results found for '{query}'."
    return "\n".join(f"[{r['title']}] ({r['url']}) {r['content'][:400]}"
                     for r in results)

# ---- Long-term memory: read and write memory.json ----
def load_memory():
    """Return the list of saved facts (empty if there is no file yet)."""
    if not os.path.exists(MEMORY_FILE):
        return []
    with open(MEMORY_FILE, encoding="utf-8") as f:
        return json.load(f)

def save_memory(question, answer):
    """Add one question + answer (with today's date) to memory.json."""
    memory = load_memory()
    memory.append({"date": today, "question": question, "answer": answer})
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(memory, f, indent=2, ensure_ascii=False)

def memory_text():
    """Turn the saved facts into text we can put in the prompt."""
    memory = load_memory()
    if not memory:
        return "(empty)"
    return "\n".join(f"- [{m['date']}] Q: {m['question']} A: {m['answer']}"
                     for m in memory)

def perform_task(task):
    """Run the Think -> Act -> Observe loop for one task and return the answer."""
    print(f"\n########## TASK: {task} ##########")
    print("=== Memory loaded into the prompt ===")
    print(memory_text())

    prompt = f"""Task: {task}
Today is {today}.
Memory (what you learned before, with the date you learned it):
{memory_text()}

You can use ONE tool: search[query] searches the web (Tavily) and returns the top results.
If your memory already answers the task, you may finish without searching.
Work in steps. Each step has a Thought, an Action, and an Observation."""

    for step in range(1, 6):          # at most 5 rounds, so it cannot loop forever
        # ---- Step 1: THINK (Reasoning) ----
        thought = ask(prompt + f"\n\nThought {step}: (reason briefly about what to do next; do not act yet)",
                      stop=["Action"])   # stop the model inventing its own Action/Observation
        print(f"=== Round {step} - Thought ===")
        print(thought)

        # ---- Step 2: ACT — append the reasoning trace, then ask for an action ----
        prompt = prompt + f"\n\nThought {step}: {thought}"
        action = ask(prompt + "\n\nWhat action should be taken based on that? "
                     "Reply with ONLY: search[query] or finish[answer]").strip()
        print(f"=== Round {step} - Action chosen by the model ===")
        print(action)

        if action.startswith("finish"):
            found = re.search(r"finish\[(.*)\]", action, re.S)
            answer = found.group(1) if found else action
            print("=== Final Answer ===")
            print(answer)
            save_memory(task, answer)   # long-term memory: keep it for next time
            return answer

        # ---- Step 3: OBSERVE — our Python code (not the model) runs the tool ----
        query = re.search(r"search\[(.*)\]", action, re.S)
        observation = search_tavily(query.group(1)) if query else "Invalid action."
        print(f"=== Round {step} - Observation from Tavily web search ===")
        print(observation)
        prompt = prompt + f"\nAction {step}: {action}\nObservation {step}: {observation}"   # short-term memory
    else:
        print("=== Stopped: no answer after 5 rounds ===")

# Start each run with an EMPTY long-term memory (overwrites any old memory.json)
with open(MEMORY_FILE, "w", encoding="utf-8") as f:
    json.dump([], f)

perform_task("When did Mark launch Muse")
perform_task("Is it available in Hong Kong yet?")
