# Same agent as ReAct06.py (Tavily search + memory.json), but built with LANGCHAIN.
# In ReAct06 we wrote the Think -> Act -> Observe loop ourselves.
# Here create_agent() runs that loop for us:
#   - @tool turns a normal Python function into a tool the model can call
#   - the model asks for a tool with "function calling" (no search[...] text to parse with re)
#   - LangChain runs the tool, gives the result back to the model, and repeats until it answers
# MEMORY: short-term = the list of messages inside ONE task (kept by LangChain).
#         long-term  = memory.json, which keeps answers AFTER a task ends,
#                      so the next task in this run can use them.
# Each run starts with an empty memory.json (see the bottom of this file).
import os
import json
from datetime import datetime
from tavily import TavilyClient
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent
from dotenv import load_dotenv
load_dotenv()

MEMORY_FILE = "memory.json"    # long-term memory lives in this file
today = datetime.now().strftime('%Y-%m-%d')

model = ChatOpenAI(
    model="deepseek-flash",
    api_key=os.environ.get('DEEPSEEK_API_KEY'),
    base_url="https://api.deepseek.com")
tavily = TavilyClient(api_key=os.environ.get('TAVILY_API_KEY'))

# The only tool (action) our agent can use — @tool makes it usable by LangChain
@tool
def search_tavily(query: str) -> str:
    """Search the web (Tavily) and return the top results (title, url, short content)."""
    results = tavily.search(query=query, max_results=3)["results"]
    if not results:
        return f"No web results found for '{query}'."
    return "\n".join(f"[{r['title']}] ({r['url']}) {r['content'][:400]}"
                     for r in results)

# ---- Long-term memory: read and write memory.json ----
def load_memory():
    """Return the list of saved facts (empty if there is no file yet)."""
    if not os.path.exists(MEMORY_FILE):
        return []
    with open(MEMORY_FILE, encoding="utf-8") as f:
        return json.load(f)

def save_memory(question, answer):
    """Add one question + answer (with today's date) to memory.json."""
    memory = load_memory()
    memory.append({"date": today, "question": question, "answer": answer})
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(memory, f, indent=2, ensure_ascii=False)

def memory_text():
    """Turn the saved facts into text we can put in the prompt."""
    memory = load_memory()
    if not memory:
        return "(empty)"
    return "\n".join(f"- [{m['date']}] Q: {m['question']} A: {m['answer']}"
                     for m in memory)

# LangChain builds the whole Think -> Act -> Observe loop for us
agent = create_agent(
    model=model,
    tools=[search_tavily],
    system_prompt=f"""You are a helpful research assistant. Today is {today}.
Use the search_tavily tool when you need up-to-date facts.
If your memory already answers the task, you may answer without searching.""",
)

def perform_task(task):
    """Let the LangChain agent do one task, print each step, and return the answer."""
    print(f"\n########## TASK: {task} ##########")
    print("=== Memory loaded into the prompt ===")
    print(memory_text())

    prompt = f"""Task: {task}
Memory (what you learned before, with the date you learned it):
{memory_text()}"""
    result = agent.invoke({"messages": [{"role": "user", "content": prompt}]})

    # Show the steps LangChain ran for us (the same Thought / Action / Observation as ReAct06)
    for message in result["messages"][1:]:          # [0] is our own prompt
        label = message.__class__.__name__
        if getattr(message, "tool_calls", None):    # the model chose an Action
            if message.content:
                print(f"=== {label} - Thought ===\n{message.content}")
            for call in message.tool_calls:
                print(f"=== {label} - Action ===\n{call['name']}({call['args']})")
        elif label == "ToolMessage":                # the tool's result
            print(f"=== {label} - Observation from Tavily web search ===\n{message.content}")

    answer = result["messages"][-1].content
    print("=== Final Answer ===")
    print(answer)
    save_memory(task, answer)   # long-term memory: keep it for next time
    return answer

# Start each run with an EMPTY long-term memory (overwrites any old memory.json)
with open(MEMORY_FILE, "w", encoding="utf-8") as f:
    json.dump([], f)

perform_task("When did Mark launch Muse")
perform_task("Is it available in Hong Kong yet?")
