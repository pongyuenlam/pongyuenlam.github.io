# ReAct07 — the same memory agent, rebuilt with LangChain

Versions 1 to 6 wrote the Think → Act → Observe loop by hand. This version
hands the loop to LangChain: `@tool` makes the search function callable by
the model, and `create_agent()` thinks, acts, observes and repeats until the
model answers. Long-term memory is unchanged — answers are still saved to
`memory.json` and loaded into the next prompt.

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with two lines:

   ```
   DEEPSEEK_API_KEY=your-deepseek-key
   TAVILY_API_KEY=your-tavily-key
   ```

   Keys: [DeepSeek console](https://platform.deepseek.com/api_keys) and
   [Tavily](https://app.tavily.com/) (both have free starting credit).
3. In the Terminal, run:

   ```
   uv sync
   uv run ReAct07.py
   ```

## What to look at

- The printout labels each step with a message type: `AIMessage` for the
  model's Thought and Action, `ToolMessage` for the Observation.
- Notice that the model can call the search tool twice in one turn —
  function calling is not limited to one action per round.
- `memory.json` works exactly as in ReAct06; compare the two printouts side
  by side to see that changing the framework did not change the behaviour.
