"""Serves the web page and hands the browser a token to join a LiveKit room.

Run: python server.py, then open http://localhost:8080
"""

import os
import uuid
from datetime import timedelta
from pathlib import Path

from aiohttp import web
from dotenv import load_dotenv
from livekit import api

load_dotenv(dotenv_path=Path(__file__).parent / ".env")

AGENT_NAME = "avatar-demo"  # must match agent.py


async def token(request: web.Request) -> web.Response:
    # Demo only: no auth. Put this behind your app's login in anything real.
    room = f"avatar-demo-{uuid.uuid4().hex[:8]}"  # fresh room per visit
    jwt = (
        api.AccessToken()  # reads LIVEKIT_API_KEY / LIVEKIT_API_SECRET
        .with_identity(f"user-{uuid.uuid4().hex[:8]}")
        .with_ttl(timedelta(minutes=15))
        .with_grants(api.VideoGrants(room_join=True, room=room))
        .with_room_config(
            api.RoomConfiguration(
                sync_streams=True,  # keeps the avatar's lips in sync with its audio
                agents=[api.RoomAgentDispatch(agent_name=AGENT_NAME)],  # sends our agent in
            )
        )
        .to_jwt()
    )
    return web.json_response({"url": os.environ["LIVEKIT_URL"], "token": jwt})


async def index(request: web.Request) -> web.FileResponse:
    return web.FileResponse(
        Path(__file__).parent / "index.html", headers={"Cache-Control": "no-store"}
    )


async def step(request: web.Request) -> web.FileResponse:
    # /step01/ serves step01/index.html, /step02/ serves step02/index.html, ...
    page = Path(__file__).parent / request.match_info["step"] / "index.html"
    if not page.is_file():
        raise web.HTTPNotFound()
    return web.FileResponse(page)


async def step_asset(request: web.Request) -> web.FileResponse:
    # /step09/site.js serves step09/site.js. Only .js and .css, so agent.py and FAQs stay private.
    asset = Path(__file__).parent / request.match_info["step"] / request.match_info["file"]
    if not asset.is_file():
        raise web.HTTPNotFound()
    return web.FileResponse(asset)


@web.middleware
async def no_cache(request: web.Request, handler):
    # Always send the latest site.js / site.css, so edits show up on a normal reload.
    response = await handler(request)
    response.headers["Cache-Control"] = "no-store"
    return response


app = web.Application(middlewares=[no_cache])
app.router.add_get("/", index)
app.router.add_get("/token", token)
app.router.add_get(r"/{step:step\d\d}/", step)  # one folder per step in the series
app.router.add_get(r"/{step:step\d\d}/{file:[\w-]+\.(?:js|css)}", step_asset)  # a step's own site.js / site.css
static_dir = Path(__file__).parent / "static"
if static_dir.is_dir():  # optional: shared site.css + site.js, only if the folder exists
    app.router.add_static("/static", static_dir)

if __name__ == "__main__":
    web.run_app(app, host="127.0.0.1", port=8080)
