# Run the LiveKit + Synthesia Avatar (V2) on your own computer

A talking AI avatar you can chat with in your browser. LiveKit handles the
conversation pipeline (microphone &rarr; speech-to-text &rarr; LLM &rarr;
text-to-speech &rarr; avatar), and Synthesia renders a photorealistic face whose
lips match the audio.

This is version 2: everything the avatar knows lives in a plain text file called
`FAQs.txt`. Edit that file, start a new call, and the avatar picks up the change
&mdash; no need to touch any code.

For the full explanation of how it works, read the
[online AI note](https://pongyuenlam.github.io/notes/ai-note22.html).

---

## 1. What you need

- A Mac, Windows, or Linux computer.
- The `uv` Python package manager.
  - On a Mac with [Homebrew](https://pongyuenlam.github.io/notes/ai-note18.html):
    run `brew install uv`.
  - Otherwise, see the [uv install guide](https://docs.astral.sh/uv/getting-started/installation/).
- A free [LiveKit Cloud](https://cloud.livekit.io/) account (the **Build** plan
  is enough).
- A [Synthesia](https://www.synthesia.io/) account with at least one avatar
  created there (the free plan lets you try).
- Your LiveKit and Synthesia credentials (see next section).

## 2. Get your credentials

### LiveKit

1. Sign up at [cloud.livekit.io](https://cloud.livekit.io/).
2. Click **Projects** &rarr; **Create Project**, open the project, and go to
   **Keys**.
3. Copy these three values:
   - `LIVEKIT_URL` &mdash; looks like `wss://your-project.livekit.cloud`
   - `LIVEKIT_API_KEY` &mdash; a short string like `APIxxxxxxxxxxxxx`
   - `LIVEKIT_API_SECRET` &mdash; a long string, shown only once

### Synthesia

1. Sign in at [app.synthesia.io](https://app.synthesia.io/).
2. Go to **Avatars**, pick or create an avatar, open it, and copy the UUID from
   the URL (e.g. `3190429b-1eda-4151-bf24-96162e405840`). That is
   `SYNTHESIA_AVATAR_ID`.
3. Go to **API Keys** and create a key. That is `SYNTHESIA_API_KEY`.

## 3. Files in this zip

- `agent.py` &mdash; the voice agent and avatar engine
- `server.py` &mdash; the web server that serves the browser page
- `index.html` &mdash; the page you open in the browser
- `FAQs.txt` &mdash; the avatar's knowledge base (edit this!)
- `pyproject.toml` &mdash; the Python project setup
- `README.md` &mdash; this file

## 4. Create your `.env` file

In the project folder, create a file named exactly `.env` with these five lines
(put your real values after the `=` signs):

```
LIVEKIT_URL=wss://your-project.livekit.cloud
LIVEKIT_API_KEY=APIxxxxxxxxxxxxx
LIVEKIT_API_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SYNTHESIA_API_KEY=syn_xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SYNTHESIA_AVATAR_ID=3190429b-1eda-4151-bf24-96162e405840
```

> **Important:** never upload `.env` to GitHub or any public site. It contains
> your live credentials.

## 5. Install dependencies (only the first time)

Open the folder in VS Code, and in the Terminal run:

```
uv sync
```

This installs Python 3.13 and every package the program needs. You only run
this once.

## 6. Run the program &mdash; two terminals

The avatar uses **two processes at the same time**, so you need two Terminal
windows.

### Terminal 1 &mdash; the voice agent + avatar engine

```
uv run agent.py dev
```

### Terminal 2 &mdash; the web server for the browser page

```
uv run server.py
```

After the first time you only need these two commands (not `uv sync` again).

## 7. Open the page in your browser

With both terminals running, open:

[http://127.0.0.1:8080](http://127.0.0.1:8080)

Click **Start**, allow the microphone permission, and wait a few seconds while
the agent and avatar join the room. You should see a video of the avatar
greeting you. Click the microphone icon and ask a question, for example:

- "Where are you located?"
- "What main courses do you serve?"

## 8. Change what the avatar knows

Open `FAQs.txt` in a text editor and add or edit your questions and answers.
Save the file, refresh the browser page, and start a new call &mdash; the
avatar will use the updated knowledge. No restart of the terminals is needed.

## 9. Common problems

| Symptom | What to do |
| --- | --- |
| `ModuleNotFoundError` or missing package | Run `uv sync` again. |
| Error about `.env` | Make sure the file is named exactly `.env` (starts with a dot) and sits in the same folder as `agent.py`. |
| Avatar never appears | Check that your LiveKit URL, key and secret are correct, and that the Synthesia API key and avatar ID are correct. |
| Avatar appears but does not answer | Check the Synthesia API key is valid and the avatar ID matches an avatar in your Synthesia account. |
| The page is blank | Make sure Terminal 2 (`uv run server.py`) is running, then open `http://127.0.0.1:8080` again. |

## 10. More information

Read the full AI note for a step-by-step explanation of the code:

[How to make a talking AI avatar with a text knowledge base (version 2)?](https://pongyuenlam.github.io/notes/ai-note22.html)
