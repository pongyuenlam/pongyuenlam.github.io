import os
from dotenv import load_dotenv
load_dotenv()
import requests
from bs4 import BeautifulSoup
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_huggingface import HuggingFaceEmbeddings

from langchain_openai import ChatOpenAI
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
my_model = ChatOpenAI(
    api_key=DEEPSEEK_API_KEY,
    base_url="https://api.deepseek.com",
    model_name="deepseek-chat" 
)
embeddings = HuggingFaceEmbeddings(
    model_name="BAAI/bge-m3"
)

urls = [
    "https://pongyuenlam.github.io/biography.html",
]

docs = []
for url in urls:
    html = requests.get(url).text
    text = BeautifulSoup(html, "html.parser").get_text()
    docs.append([Document(page_content=text, metadata={"source": url})])
docs_list = []
for sublist in docs:
    for item in sublist:
        docs_list.append(item)
text_splitter = RecursiveCharacterTextSplitter(chunk_size=300, chunk_overlap=100)
chunks = text_splitter.split_documents(docs_list)

vectorstore = InMemoryVectorStore.from_documents(chunks, embeddings)
retriever = vectorstore.as_retriever(search_kwargs={"k": 1})

print("Before RAG")
before_rag_template = "{topic}"
before_rag_prompt = ChatPromptTemplate.from_template(before_rag_template)
before_rag_chain = before_rag_prompt | my_model | StrOutputParser()
user_question = "What is the Chinese name of Howard Lam?"

print(before_rag_chain.invoke({"topic": user_question}))

print("After RAG")
after_rag_template = """Answer the question based only on the following context:
{context}
Question: {question}
"""
after_rag_prompt = ChatPromptTemplate.from_template(after_rag_template)
after_rag_chain = (
    {"context": retriever, "question": RunnablePassthrough()}
    | after_rag_prompt
    | my_model
    | StrOutputParser()
)
results = after_rag_chain.invoke(user_question)
print("Retrieved chunk:", retriever.invoke(user_question)[0].page_content)
print(results)

