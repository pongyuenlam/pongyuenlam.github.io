import torch
from torch.utils.data import TensorDataset, DataLoader, Subset
import pandas as pd
def create_sliding_windows_with_target(data, window_size, shift=1):
    windows = data.unfold(0, window_size, shift)
    row_n = windows.shape[0]
    col_n = windows.shape[1]
    features = windows[0:row_n, 0:col_n-1]  # All columns except the last
    targets = windows[0:row_n, col_n-1:col_n]   # Just the last column
    return features, targets

df = pd.read_csv('time_series.csv')
series = df['series'].values
series_tensor = torch.tensor(series, dtype=torch.float32)
window_size = 30
features, targets = create_sliding_windows_with_target(series_tensor, window_size=window_size, shift=1)
# Create PyTorch Dataset and DataLoader
dataset = TensorDataset(features, targets)
batch_size = 32
train_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# Print some information about the dataset
print(f"Series length: {len(series)}")
print(f"Number of windows: {len(features)}")
print(f"Feature shape: {features.shape}")  # Should be (num_windows, window_size-1)
print(f"Target shape: {targets.shape}")    # Should be (num_windows, 1)

# Show a few examples
print("\nFirst few windows:")
for i in range(3):
    print(f"\nWindow {i+1}:")
    print(f"Features (previous {window_size-1} days): {[f'{x:.2f}' for x in features[i].numpy()]}")
    print(f"Target (next day): {targets[i].item():.2f}")

