import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import torch
import torch.nn as nn
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from torch.utils.data import TensorDataset, DataLoader, Subset

# ── Best config, read from search_results_12.xlsx (Rank 1) ───────────────────
RESULTS_FILE = "search_results_12.xlsx"
MODEL_FILE   = "best_model_12.pt"
BATCH_SIZE   = 32

results  = pd.read_excel(RESULTS_FILE)
best_row = results.sort_values("r2", ascending=False).iloc[0]

BEST_CFG = {
    "window_size": int(best_row["window_size"]),
    "hidden_size": int(best_row["hidden_size"]),
    "num_layers":  int(best_row["num_layers"]),
}

# ── Load data ─────────────────────────────────────────────────────────────────
df = pd.read_csv("time_series.csv")
series = df["series"].values
series_tensor = torch.tensor(series, dtype=torch.float32)

window_size = BEST_CFG["window_size"]
windows     = series_tensor.unfold(0, window_size, 1)
features    = windows[:, :-1]
targets     = windows[:, -1:]
full_dataset = TensorDataset(features, targets)

total   = len(full_dataset)
val_end = int(total * 0.85)
test_loader = DataLoader(Subset(full_dataset, range(val_end, total)),
                         batch_size=BATCH_SIZE, shuffle=False)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ── Rebuild model architecture & load weights ─────────────────────────────────
def build_model(input_size, hidden_size, num_layers):
    layers, in_dim = [], input_size
    for _ in range(num_layers):
        layers += [nn.Linear(in_dim, hidden_size), nn.ReLU()]
        in_dim = hidden_size
    layers.append(nn.Linear(in_dim, 1))
    return nn.Sequential(*layers)

model = build_model(window_size - 1, BEST_CFG["hidden_size"], BEST_CFG["num_layers"])
model.load_state_dict(torch.load(MODEL_FILE, map_location=device))
model.to(device)
model.eval()
print(f"Loaded: {MODEL_FILE}")
print(f"Config: {BEST_CFG}\n")

# ── Evaluate ──────────────────────────────────────────────────────────────────
preds, actuals = [], []
with torch.no_grad():
    for xb, yb in test_loader:
        preds.extend(model(xb.to(device)).cpu().numpy())
        actuals.extend(yb.numpy())

p = torch.tensor(np.array(preds))
a = torch.tensor(np.array(actuals))

mae  = torch.mean(torch.abs(p - a)).item()
mse  = torch.mean((p - a) ** 2).item()
rmse = torch.sqrt(torch.tensor(mse)).item()
r2   = (1 - torch.sum((a - p) ** 2) / torch.sum((a - torch.mean(a)) ** 2)).item()

print(f"Test Set Metrics:")
print(f"  MAE:  {mae:.4f}")
print(f"  MSE:  {mse:.4f}")
print(f"  RMSE: {rmse:.4f}")
print(f"  R²:   {r2:.4f}")

# ── Plots ─────────────────────────────────────────────────────────────────────
# 1. Predictions vs actual
plt.figure(figsize=(12, 5))
plt.plot(actuals, label="Actual",    color="lightgrey", linewidth=1.5)
plt.plot(preds,   label="Predicted", color="red",       linewidth=1.5)
plt.title(f"Best Model — Predictions vs Actual (Test Set)\nR²={r2:.4f}  RMSE={rmse:.4f}", fontsize=11)
plt.xlabel("Time"); plt.ylabel("Value")
plt.legend(); plt.grid(True)
plt.tight_layout()
plt.savefig("best_model_predictions.png", dpi=150)
plt.show()
print("Saved: best_model_predictions.png")
