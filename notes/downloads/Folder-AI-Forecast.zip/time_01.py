import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv('time_series.csv')
series = df['series'].values
plt.plot(series)
plt.title('Sales per day')
plt.xlabel('Day')
plt.ylabel('Sales-HK$')
plt.grid(True)
plt.show()

