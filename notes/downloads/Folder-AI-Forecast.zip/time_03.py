import torch
def create_sliding_windows(data, window_size, shift):
    windows = data.unfold(0, window_size, shift)
    return windows
data = torch.arange(1, 60)
window_size = 30
windows = create_sliding_windows(data, window_size, 1)
for window in windows:
    print(window.numpy())


    