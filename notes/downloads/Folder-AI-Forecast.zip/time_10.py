import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader, Subset
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import random
import itertools

# ── Reproducibility ──────────────────────────────────────────────────────────
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

# ── Search space ─────────────────────────────────────────────────────────────
SEARCH_SPACE = {
    "epochs":       [50, 100, 200],
    "learning_rate":[0.001, 0.01, 0.1],
    "optimizer":    ["Adam", "SGD", "RMSprop"],
    "hidden_size":  [10, 32, 64],
    "num_layers":   [1, 2, 3],
}
N_TRIALS      = 20
EARLY_STOP_PATIENCE = 15   # stop if val loss doesn't improve for this many epochs
WINDOW_SIZE   = 30
BATCH_SIZE    = 32

# ── Data ─────────────────────────────────────────────────────────────────────
df = pd.read_csv("time_series.csv")
series = df["series"].values
series_tensor = torch.tensor(series, dtype=torch.float32)

def create_sliding_windows(data, window_size):
    windows  = data.unfold(0, window_size, 1)
    features = windows[:, :-1]
    targets  = windows[:, -1:]
    return features, targets

features, targets = create_sliding_windows(series_tensor, WINDOW_SIZE)
full_dataset = TensorDataset(features, targets)

total   = len(full_dataset)
tr_end  = int(total * 0.70)
val_end = int(total * 0.85)

train_loader = DataLoader(Subset(full_dataset, range(tr_end)),          batch_size=BATCH_SIZE, shuffle=True)
val_loader   = DataLoader(Subset(full_dataset, range(tr_end, val_end)), batch_size=BATCH_SIZE, shuffle=False)
test_loader  = DataLoader(Subset(full_dataset, range(val_end, total)),  batch_size=BATCH_SIZE, shuffle=False)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ── Model factory ─────────────────────────────────────────────────────────────
def build_model(hidden_size, num_layers):
    input_size = WINDOW_SIZE - 1
    layers = []
    in_dim = input_size
    for _ in range(num_layers):
        layers += [nn.Linear(in_dim, hidden_size), nn.ReLU()]
        in_dim = hidden_size
    layers.append(nn.Linear(in_dim, 1))
    return nn.Sequential(*layers).to(device)

def get_optimizer(name, params, lr):
    return {"Adam": optim.Adam, "SGD": optim.SGD, "RMSprop": optim.RMSprop}[name](params, lr=lr)

# ── Train one trial ───────────────────────────────────────────────────────────
def train_trial(cfg):
    model     = build_model(cfg["hidden_size"], cfg["num_layers"])
    criterion = nn.MSELoss()
    optimizer = get_optimizer(cfg["optimizer"], model.parameters(), cfg["learning_rate"])

    best_val_loss = float("inf")
    best_state    = {k: v.clone() for k, v in model.state_dict().items()}
    patience_ctr  = 0
    train_losses, val_losses = [], []

    for epoch in range(cfg["epochs"]):
        # train
        model.train()
        t_loss = 0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            optimizer.step()
            t_loss += loss.item()
        t_loss /= len(train_loader)

        # validate
        model.eval()
        v_loss = 0
        with torch.no_grad():
            for xb, yb in val_loader:
                v_loss += criterion(model(xb.to(device)), yb.to(device)).item()
        v_loss /= len(val_loader)

        train_losses.append(t_loss)
        val_losses.append(v_loss)

        # early stopping
        if v_loss < best_val_loss:
            best_val_loss = v_loss
            best_state    = {k: v.clone() for k, v in model.state_dict().items()}
            patience_ctr  = 0
        else:
            patience_ctr += 1
            if patience_ctr >= EARLY_STOP_PATIENCE:
                break

    model.load_state_dict(best_state)
    return model, train_losses, val_losses

# ── Evaluate on test set ──────────────────────────────────────────────────────
def evaluate(model):
    model.eval()
    preds, actuals = [], []
    with torch.no_grad():
        for xb, yb in test_loader:
            preds.extend(model(xb.to(device)).cpu().numpy())
            actuals.extend(yb.numpy())
    p = torch.tensor(np.array(preds))
    a = torch.tensor(np.array(actuals))
    mae  = torch.mean(torch.abs(p - a)).item()
    rmse = torch.sqrt(torch.mean((p - a) ** 2)).item()
    ss_res = torch.sum((a - p) ** 2)
    ss_tot = torch.sum((a - torch.mean(a)) ** 2)
    r2 = (1 - ss_res / ss_tot).item()
    return r2, mae, rmse, preds, actuals

# ── Random search ─────────────────────────────────────────────────────────────
keys   = list(SEARCH_SPACE.keys())
combos = list(itertools.product(*SEARCH_SPACE.values()))
sampled = random.sample(combos, min(N_TRIALS, len(combos)))

results = []
best_r2    = -float("inf")
best_trial = None

print(f"Running {N_TRIALS} random trials...\n")
print(f"{'Trial':>5}  {'Epochs':>6}  {'LR':>6}  {'Opt':>7}  {'Hidden':>6}  {'Layers':>6}  {'R2':>8}  {'RMSE':>10}")
print("-" * 70)

for i, combo in enumerate(sampled):
    cfg = dict(zip(keys, combo))
    model, t_losses, v_losses = train_trial(cfg)
    r2, mae, rmse, preds, actuals = evaluate(model)

    row = {**cfg, "r2": round(r2, 4), "mae": round(mae, 4), "rmse": round(rmse, 4),
           "actual_epochs": len(t_losses)}
    results.append(row)

    print(f"{i+1:>5}  {cfg['epochs']:>6}  {cfg['learning_rate']:>6}  "
          f"{cfg['optimizer']:>7}  {cfg['hidden_size']:>6}  {cfg['num_layers']:>6}  "
          f"{r2:>8.4f}  {rmse:>10.4f}")

    if r2 > best_r2:
        best_r2    = r2
        best_trial = {"cfg": cfg, "model": model, "t_losses": t_losses,
                      "v_losses": v_losses, "preds": preds, "actuals": actuals,
                      "r2": r2, "mae": mae, "rmse": rmse}

# ── Save best model ───────────────────────────────────────────────────────────
torch.save(best_trial["model"].state_dict(), "best_model.pt")
print(f"\nBest model saved → best_model.pt")
print(f"Best config : {best_trial['cfg']}")
print(f"Best R²     : {best_trial['r2']:.4f}  |  MAE: {best_trial['mae']:.4f}  |  RMSE: {best_trial['rmse']:.4f}")

# ── Save results table ────────────────────────────────────────────────────────
results_df = pd.DataFrame(results).sort_values("r2", ascending=False).reset_index(drop=True)
results_df.index += 1
results_df.to_excel("search_results.xlsx", index_label="Rank")
print("Results table saved → search_results.xlsx")

# ── Plots for best model only ─────────────────────────────────────────────────
# 1. Loss curves
plt.figure(figsize=(10, 5))
plt.plot(best_trial["t_losses"], label="Train Loss")
plt.plot(best_trial["v_losses"], label="Val Loss")
plt.title(f"Best Model — Loss Curves\n{best_trial['cfg']}", fontsize=11)
plt.xlabel("Epoch"); plt.ylabel("MSE Loss")
plt.legend(); plt.grid(True)
plt.tight_layout()
plt.savefig("best_model_loss.png", dpi=150)
plt.show()

# 2. Predictions vs actual
plt.figure(figsize=(12, 5))
plt.plot(best_trial["actuals"], label="Actual",    color="lightgrey", linewidth=1.5)
plt.plot(best_trial["preds"],   label="Predicted", color="red",       linewidth=1.5)
plt.title(f"Best Model — Predictions vs Actual (Test Set)\nR²={best_trial['r2']:.4f}  RMSE={best_trial['rmse']:.4f}", fontsize=11)
plt.xlabel("Time"); plt.ylabel("Value")
plt.legend(); plt.grid(True)
plt.tight_layout()
plt.savefig("best_model_predictions.png", dpi=150)
plt.show()

# 3. R² bar chart across all trials
plt.figure(figsize=(12, 4))
colors = ["#4472C4" if r < best_r2 else "#70AD47" for r in results_df["r2"]]
plt.bar(results_df.index, results_df["r2"], color=colors)
plt.axhline(best_r2, color="red", linestyle="--", linewidth=1, label=f"Best R²={best_r2:.4f}")
plt.title("R² Across All Trials (green = best)")
plt.xlabel("Rank"); plt.ylabel("R²")
plt.legend(); plt.grid(axis="y", alpha=0.4)
plt.tight_layout()
plt.savefig("trial_r2_chart.png", dpi=150)
plt.show()
