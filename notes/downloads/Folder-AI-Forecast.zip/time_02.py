import torch
data = torch.arange(10)
print(data)
# the unfold method extracts sliding windows along dimension 0 
# (the only dimension here)
# window length is 5, and the windows shift by 1 element
windows = data.unfold(0, 5, 1)
for window in windows:
    print(window.numpy())

    
