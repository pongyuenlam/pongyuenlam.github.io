import torch
from torch.utils.data import TensorDataset, DataLoader, Subset
import pandas as pd
import matplotlib.pyplot as plt

def create_sliding_windows_with_target(data, window_size, shift=1):
    windows = data.unfold(0, window_size, shift)
    features = windows[:, :-1]
    targets = windows[:, -1:]
    return features, targets

df = pd.read_csv('time_series.csv')
series = df['series'].values
series_tensor = torch.tensor(series, dtype=torch.float32)
window_size = 30
features, targets = create_sliding_windows_with_target(series_tensor, window_size=window_size, shift=1)
full_dataset = TensorDataset(features, targets)

total_windows = len(full_dataset)
train_size = int(total_windows * 0.7)
val_size = int(total_windows * 0.15)
test_size = total_windows - train_size - val_size

train_indices = list(range(train_size))
val_indices = list(range(train_size, train_size + val_size))
test_indices = list(range(train_size + val_size, total_windows))

train_dataset = Subset(full_dataset, train_indices)
val_dataset = Subset(full_dataset, val_indices)
test_dataset = Subset(full_dataset, test_indices)

batch_size = 32
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# Visualize train/val/test split
val_start = train_size
test_start = train_size + val_size
plt.figure(figsize=(12, 4))
plt.plot(range(val_start), series[:val_start], 'b-', label='Training Data')
plt.plot(range(val_start, test_start), series[val_start:test_start], 'r-', label='Validation Data')
plt.plot(range(test_start, len(series)), series[test_start:], 'g-', label='Test Data')
plt.axvline(x=val_start, color='k', linestyle='--', label='Train/Val Split')
plt.axvline(x=test_start, color='purple', linestyle='--', label='Val/Test Split')
plt.title('Time Series Train/Validation/Test Split')
plt.xlabel('Time')
plt.ylabel('Value')
plt.legend()
plt.grid(True)
plt.show()

import torch.nn as nn
import torch.optim as optim

class TimeSeriesModel(nn.Module):
    def __init__(self, window_size):
        super(TimeSeriesModel, self).__init__()
        self.network = nn.Sequential(
            nn.Linear(window_size - 1, 10),
            nn.ReLU(),
            nn.Linear(10, 10),
            nn.ReLU(),
            nn.Linear(10, 1)
        )

    def forward(self, x):
        return self.network(x)

model = TimeSeriesModel(window_size)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters())

num_epochs = 100
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model.to(device)

train_losses = []
val_losses = []

for epoch in range(num_epochs):
    model.train()
    train_loss = 0
    for batch_features, batch_targets in train_loader:
        batch_features = batch_features.to(device)
        batch_targets = batch_targets.to(device)
        outputs = model(batch_features)
        loss = criterion(outputs, batch_targets)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        train_loss += loss.item()

    model.eval()
    val_loss = 0
    with torch.no_grad():
        for batch_features, batch_targets in val_loader:
            batch_features = batch_features.to(device)
            batch_targets = batch_targets.to(device)
            outputs = model(batch_features)
            val_loss += criterion(outputs, batch_targets).item()

    train_loss /= len(train_loader)
    val_loss /= len(val_loader)
    train_losses.append(train_loss)
    val_losses.append(val_loss)

    if (epoch + 1) % 10 == 0:
        print(f'Epoch [{epoch+1}/{num_epochs}], '
              f'Train Loss: {train_loss:.4f}, '
              f'Val Loss: {val_loss:.4f}')

# Plot training progress
plt.figure(figsize=(10, 6))
plt.plot(train_losses, label='Training Loss')
plt.plot(val_losses, label='Validation Loss')
plt.title('Model Loss Over Time')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)
plt.show()

# Evaluate on test set
model.eval()
test_predictions = []
test_targets = []
with torch.no_grad():
    for batch_features, batch_targets in test_loader:
        batch_features = batch_features.to(device)
        outputs = model(batch_features)
        test_predictions.extend(outputs.cpu().numpy())
        test_targets.extend(batch_targets.numpy())

# Plot predictions vs actual for test set
plt.figure(figsize=(10, 6))
plt.plot(test_targets, label='Actual', color='lightgrey')
plt.plot(test_predictions, label='Predicted', color='red')
plt.title('Predictions vs Actual Values (Test Set)')
plt.xlabel('Time')
plt.ylabel('Value')
plt.legend()
plt.grid(True)
plt.show()

# Metrics on test set
test_predictions_tensor = torch.tensor(test_predictions)
test_targets_tensor = torch.tensor(test_targets)

mae = torch.mean(torch.abs(test_predictions_tensor - test_targets_tensor))
mse = torch.mean((test_predictions_tensor - test_targets_tensor) ** 2)
rmse = torch.sqrt(mse)
ss_res = torch.sum((test_targets_tensor - test_predictions_tensor) ** 2)
ss_tot = torch.sum((test_targets_tensor - torch.mean(test_targets_tensor)) ** 2)
r2 = 1 - ss_res / ss_tot

print(f"\nTest Set Metrics:")
print(f"  MAE:  {mae:.4f}")
print(f"  MSE:  {mse:.4f}")
print(f"  RMSE: {rmse:.4f}")
print(f"  R²:   {r2:.4f}")
