# ReAct04 — the agent as a reusable function

Same think, search, observe loop as ReAct03, now wrapped in
`perform_task(task)`. Change the last line to any question, run again, and the
function returns the answer as text your program can use.

## Files

- `ReAct04.py` — the agent, one function plus a single call
- `pyproject.toml` — the package list (`openai`, `tavily-python`, `python-dotenv`)
- `README.md` — this file

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with two lines:

   ```
   DEEPSEEK_API_KEY=your-deepseek-key
   TAVILY_API_KEY=your-tavily-key
   ```

   DeepSeek key: https://platform.deepseek.com/api_keys
   Tavily key (free tier): https://app.tavily.com/

3. In the Terminal, run:

   ```
   uv sync
   uv run ReAct04.py
   ```

   `uv sync` is needed only the first time. It installs nothing outside this
   project.

## Expected output

Rounds of Thought, Action and Observation, then a final answer. To research
your own question, change the last line, for example:

```python
perform_task("What were the three biggest news stories in my city this week?")
```

Each search costs one Tavily credit; a run is usually two to five searches.
