# https://open-meteo.com/
import requests
def get_weather_from_ip():
    """
    Get the current temperature in Celsius for the user's location
    using the IP address and return it as a string.
    """
    location = requests.get("https://ipinfo.io/json", timeout=10).json()
    latitude, longitude = location["loc"].split(",")

    params = {
        "latitude": latitude,
        "longitude": longitude,
        "current": "temperature_2m",
        "temperature_unit": "celsius",
        "timezone": "auto",
    }

    weather_data = requests.get(
        "https://api.open-meteo.com/v1/forecast",
        params=params,
        timeout=10,
    ).json()

    return f"Current: {weather_data['current']['temperature_2m']}°C"

result = get_weather_from_ip()
print(result)

