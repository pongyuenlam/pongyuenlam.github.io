# Weather tool for an AI agent

A single Python function that turns the current temperature into one short sentence
an AI agent can quote. It finds an approximate location from the public IP address,
then asks Open-Meteo for the current temperature there. Neither service needs an API key.

Read the full explanation: https://pongyuenlam.github.io/notes/ai-note36.html

## Run it

1. Open the folder in Visual Studio Code.
2. In the Terminal, run:

   ```
   uv sync
   uv run tool02_weather.py
   ```

`uv sync` only needs to run the first time. It creates a local environment with the
one package this project needs (`requests`), so nothing is installed into the rest of
your computer.

You should see one line, for example:

```
Current: 24.6°C
```

If nothing appears, check the internet connection first. The two free services used
here — ipinfo.io and Open-Meteo — have no uptime guarantee.

## Files

- `tool02_weather.py` — the tool, with a short test at the bottom
- `pyproject.toml` — tells uv which packages to install
