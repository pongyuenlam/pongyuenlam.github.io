# ReAct03 — think, search, observe, repeat

The agent is asked "When did Mark launch Muse" and may use one tool —
`search[query]`, a real web search through Tavily. It thinks, searches, reads,
and thinks again, for up to five rounds, until it answers with `finish[...]`.

## Files

- `ReAct03.py` — the whole experiment in one file
- `pyproject.toml` — the package list (`openai`, `tavily-python`, `python-dotenv`)
- `README.md` — this file

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with two lines:

   ```
   DEEPSEEK_API_KEY=your-deepseek-key
   TAVILY_API_KEY=your-tavily-key
   ```

   DeepSeek key: https://platform.deepseek.com/api_keys
   Tavily key (free tier): https://app.tavily.com/

3. In the Terminal, run:

   ```
   uv sync
   uv run ReAct03.py
   ```

   `uv sync` is needed only the first time. It installs nothing outside this
   project.

## Expected output

Rounds of Thought, Action and Observation, then a final answer with a date.
Each search costs one Tavily credit; a full run is a handful of searches.
Try changing the task to a question about your own company or city, and watch
how many rounds the agent needs.
