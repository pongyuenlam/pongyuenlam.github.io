# Learn ONE line from ReAct09.py, step by step:
#     sentences.extend(re.split(r"(?<=[.!?])\s+", block))
# It cuts a block of text into sentences.
# Here we make our own blocks (no web page), so we can see exactly what happens.
import re

# A few blocks, like the headings, paragraphs and list items ReAct09.py takes from a web page
blocks = [
    "Howard Lam, PhD",                                    # a heading: no full stop at all
    "I teach AI for marketing. Do you like it? Yes!",     # a paragraph: three sentences
    "My average meal cost is HK$60.10 in 2025.",          # 60.10 has a "." but no space after it
]

# ---- Step 1: split on spaces only -> cuts after EVERY word (too many pieces) ----
print("=== Step 1: re.split(r'\\s+', ...) ===")
print(re.split(r"\s+", blocks[1]))
# \s means one space (or tab, or line break); \s+ means one or more of them in a row

# ---- Step 2: split on ". ! ?" plus spaces -> the punctuation is LOST ----
print("\n=== Step 2: re.split(r'[.!?]\\s+', ...) ===")
print(re.split(r"[.!?]\s+", blocks[1]))
# [.!?] means ONE character that is . or ! or ?
# The cut happens ON the punctuation, so it disappears

# ---- Step 3: the real line -> keep the punctuation ----
print("\n=== Step 3: re.split(r'(?<=[.!?])\\s+', ...) ===")
print(re.split(r"(?<=[.!?])\s+", blocks[1]))
# (?<=[.!?]) is a "look-behind": cut only at spaces that come right AFTER . ! or ?
# It only LOOKS at the punctuation and does not cut it out, so the sentence keeps its "."

# ---- Step 4: every block -> why there is no cut inside HK$60.10 ----
print("\n=== Step 4: each block on its own ===")
for block in blocks:
    print(re.split(r"(?<=[.!?])\s+", block))
# "Howard Lam, PhD" has no . ! ? so we get the whole block back as ONE sentence
# "HK$60.10" has a "." but no space after it, so it is not cut: the block stays ONE sentence

# ---- Step 5: put the sentences of ALL blocks into one list, and number them (as ReAct09.py does) ----
sentences = []
for block in blocks:
    sentences.extend(re.split(r"(?<=[.!?])\s+", block))   # extend adds each sentence as its own item
print(f"\n=== Step 5: {len(sentences)} sentences ===")
for number, sentence in enumerate(sentences, start=1):
    print(f"{number}. {sentence}")

# Try it: change a block to "Dr. Lam teaches AI." and run again.
# Why does it cut after "Dr."? (Hint: the rule only sees ". " — it does not know "Dr." is not a sentence end.)
