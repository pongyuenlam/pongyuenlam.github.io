# ReAct08 — split a block of text into sentences, step by step

The next version of our agent reads web pages. A web page arrives as big
blocks of text, and the agent works better when the text is cut into
sentences first. One line of Python does the cutting:

    sentences.extend(re.split(r"(?<=[.!?])\s+", block))

This script shows exactly what that line does, in five small steps, using
three made-up blocks: a heading, a paragraph, and a price. No web page, no
API key, nothing to install — the `re` module comes with Python.

## Run it

1. Open the folder in Visual Studio Code.
2. In the Terminal, run:

   ```
   uv python pin 3.12.10
   uv sync
   uv run ReAct08.py
   ```

## What to look at

- Step 1 cuts on spaces only: far too many pieces.
- Step 2 cuts on the punctuation itself: the `.` `!` `?` are lost.
- Step 3 uses a "look-behind": cut at spaces that come right after a `.`,
  `!` or `?`, and keep the punctuation in the sentence.
- Step 4 shows why `HK$60.10` is not cut: there is no space after the dot.
- Try changing a block to `"Dr. Lam teaches AI."` and run again. It cuts
  after `Dr.` — the rule only sees a dot followed by a space.
