**face03.py**

Encode the known faces in the "images" folder, then find the faces in `image-source.jpg`, compare each one with the known faces, and print the names of the people who match.

**Lines 1-5: Import the libraries**
```python
 1  import face_recognition
 2  import cv2
 3  import os
 4  import glob
 5  import numpy as np
```
- `face_recognition` is the library that finds faces in an image and turns each face into numbers that can be compared with other faces.
- `cv2` is **OpenCV**, the computer vision library used to read images and convert their colours.
- `os` stands for **operating system**. It is Python's built-in module for working with the computer's files and folders. It handles file paths, such as joining folder and file names, or splitting a file name from its extension.
- `glob` stands for **global**. It finds all files whose names match a pattern, such as `*.*` (any name with any extension).
- `numpy` is **NumPy** (**Numerical Python**), a library for working with lists of numbers. `as np` gives it the short name `np`.

**Lines 7-8: Find all the images in the folder**
```python
 7  images_folder = "images"
 8  images_path = glob.glob(os.path.join(images_folder, "*.*"))
```
- Line 7 stores the folder name `"images"` in a variable.
- Line 8 builds the pattern `images/*.*` with `os.path.join` (which uses the correct `/` or `\` for Mac or Windows), and `glob.glob` returns a list of every matching file path, e.g. `["images/Howard.JPG", "images/Paul.jpg", "images/Mary.jpg"]`.

**Lines 10-11: Create two empty lists for the known faces**
```python
10  known_face_encodings=[]
11  known_face_names=[]
```
- Line 10 creates an empty list that will hold the face encoding of each known person.
- Line 11 creates an empty list that will hold each person's name. The two lists are filled in the same order, so the first encoding belongs to the first name, and so on.

**Lines 12-16: Read each known image, convert its colours, and get the person's name**
```python
12  for img_path in images_path:
13      img = cv2.imread(img_path)
14      rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
15      basename = os.path.basename(img_path)
16      (filename, ext) = os.path.splitext(basename)
```
- Line 12 loops through the list, taking one file path at a time into `img_path`. Everything indented in lines 13-19 runs once per image.
- Line 13 reads the image file into `img`, a grid of pixel values in Blue Green Red (BGR) colour order.
- Line 14 uses `cvtColor` (**convert colour**) to change the colour order from BGR to RGB (**Red Green Blue**), and stores the result in `rgb_img`. OpenCV reads images as BGR, but `face_recognition` expects RGB.
- Line 15 removes the folder part: `images/Howard.JPG` becomes `Howard.JPG`.
- Line 16 splits the name from its extension: `Howard.JPG` becomes `("Howard", ".JPG")`, stored in `filename` and `ext`.

**Lines 17-19: Encode each known face and save it with the person's name**
```python
17      img_encoding = face_recognition.face_encodings(rgb_img)[0]
18      known_face_encodings.append(img_encoding)
19      known_face_names.append(filename)
```
- Line 17 turns the face in the image into a face encoding: a list of 128 numbers that describes that face. `[0]` takes the first face found, so each known image should contain one clear face.
- Line 18 adds the encoding to the end of `known_face_encodings` with `append`.
- Line 19 adds the person's name, e.g. `Howard`, to the end of `known_face_names`.

**Lines 21-24: Find and encode the faces in the source image**
```python
21  img=cv2.imread("image-source.jpg")
22  rgb_img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
23  face_locations = face_recognition.face_locations(rgb_img)
24  face_encodings = face_recognition.face_encodings(rgb_img, face_locations)
```
- Line 21 reads `image-source.jpg`, the photo we want to check for known people.
- Line 22 converts it from BGR to RGB, as in line 14.
- Line 23 finds every face in the photo. `face_locations` is a list with one position (a box around the face) for each face found.
- Line 24 turns each of those faces into a face encoding. Unlike line 17, there is no `[0]`, so it keeps the encodings of all the faces, not just the first.

**Lines 26-29: Compare each face with the known faces**
```python
26  face_names = []
27  for face_encoding in face_encodings:
28      matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
29      print(matches)
```
- Line 26 creates an empty list for the names of the people found in the photo.
- Line 27 loops through the faces in the photo, one encoding at a time. Everything indented in lines 28-37 runs once per face.
- Line 28 compares this face with each known face and gives one `True` (match) or `False` (no match) for each known person, in the same order as `known_face_names`.
- Line 29 prints the result: `[np.True_, np.False_, np.False_]`. `np.True_` and `np.False_` are NumPy's versions of `True` and `False`. So the face matches Howard but not Paul or Mary.

**Lines 30-34: Find the known face that is most similar**
```python
30      name = "Unknown"
31      face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
32      print(np.round(face_distances, 2))
33      best_match_index = np.argmin(face_distances)
34      print(best_match_index)
```
- Line 30 sets the name to `"Unknown"` as a starting value, in case no known face matches.
- Line 31 measures how different this face is from each known face. A smaller distance means the faces are more similar.
- Line 32 uses `np.round(..., 2)` to round the distances to 2 decimal places and prints them: `[0.28 0.63 0.64]`, one number for each known person. Howard's distance is `0.28`, so the face is very similar to Howard's even though it is a different photo. Paul's and Mary's are `0.63` and `0.64`. Line 28 counts a face as a match only if its distance is 0.6 or less, which is why only Howard is `True`. If we copy Howard.JPG to image-source.JPG, Howard's distance becomes `0`, because the two photos are identical.
- Line 33 uses `np.argmin` (**argument of the minimum**) to find the position of the smallest distance, i.e. the most similar known face. Positions start at 0, so `0` means the first person (Howard), `1` the second (Paul), and `2` the third (Mary).
- Line 34 prints that position: `0`, which is Howard.

**Lines 35-38: Save the name of the best match and print the results**
```python
35      if matches[best_match_index]:
36          name = known_face_names[best_match_index]
37          face_names.append(name)
38  print("The matched name's image file is",face_names)
```
- Line 35 checks that the most similar known face is also a match (`True` in line 28). Being the most similar is not enough; it also has to be similar enough.
- Line 36 looks up the person's name at that position: position `0` gives `Howard`.
- Line 37 adds the name to `face_names`. Because this line is inside the `if`, only matched faces are added. A face with no match is left out, so `"Unknown"` from line 30 never appears in the list.
- Line 38 is not indented, so it runs once after the loop has checked every face. It prints the list of matched names: `The matched name's image file is ['Howard']`.

**Output**
```
[np.True_, np.False_, np.False_]
[0.28 0.63 0.64]
0
The matched name's image file is ['Howard']
```
- The first three lines come from lines 29, 32 and 34. They are printed once because `image-source.jpg` contains one face.
- The last line comes from line 38, after the loop.
