**face04.py**

Open the computer's camera and show its live video in a window until the user presses `q` or `Q` to quit.

**Lines 1-2: Import the library and open the camera**
```python
 1  import cv2
 2  cap = cv2.VideoCapture(0)
```
- `cv2` is **OpenCV**, the computer vision library used here to read video from the camera and display it.
- Line 2 opens the camera with `VideoCapture` and stores it in `cap` (**capture**). `0` means the computer's default camera, usually the built-in webcam. If you have a second camera, `1` would open that one.

**Lines 3-5: Read and show the video, one frame at a time**
```python
 3  while True:
 4      ret, img = cap.read()
 5      cv2.imshow("Frame", img)
```
- Line 3 starts a loop that repeats forever, because `True` is always true. Everything indented in lines 4-8 runs again and again until the user quits.
- Line 4 reads one frame (one still picture) from the camera. `ret` (**return value**) is `True` if a frame was read, and `img` is the frame itself, a grid of pixel values in Blue Green Red (BGR) colour order.
- Line 5 displays the frame in a window titled `"Frame"`. Because the loop shows a new frame many times per second, it looks like live video.

**Lines 6-8: Quit when the user presses q or Q**
```python
 6      key = cv2.waitKey(1)
 7      if key in (ord('q'), ord('Q')):
 8          break
```
- Line 6 waits 1 millisecond for a key press and stores the key in `key`. If no key is pressed, `key` is `-1`. This short wait also gives OpenCV time to update the window.
- Line 7 uses `ord` (**ordinal**) to get the number code of the letters `q` and `Q`, because `waitKey` gives keys as numbers. It checks whether the key pressed is either of them.
- Line 8 uses `break` to leave the `while` loop, which stops the video.

**Lines 9-10: Close the camera and the window**
```python
 9  cap.release()
10  cv2.destroyAllWindows()
```
- Line 9 is not indented, so it runs once after the loop ends. It releases the camera so that other apps can use it, and the camera light turns off.
- Line 10 closes every window that OpenCV opened.
