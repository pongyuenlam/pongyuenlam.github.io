import face_recognition
import cv2
import os
import glob
import numpy as np
images_folder = "images"
images_path = glob.glob(os.path.join(images_folder, "*.*"))

known_face_encodings=[]
known_face_names=[]
for img_path in images_path:
    img = cv2.imread(img_path)
    rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    basename = os.path.basename(img_path)
    (filename, ext) = os.path.splitext(basename)
    img_encoding = face_recognition.face_encodings(rgb_img)[0]
    known_face_encodings.append(img_encoding)
    known_face_names.append(filename)

cap = cv2.VideoCapture(0)
scale_ratio = 0.5
multiple = int(1 / scale_ratio)
ret, img = cap.read()
width=int(img.shape[1]*scale_ratio)
height=int(img.shape[0]*scale_ratio)
dim=(width,height)

while True:
    ret, img = cap.read()
    resized=cv2.resize(img,dim,interpolation=cv2.INTER_NEAREST)
    rgb_img = cv2.cvtColor(resized,cv2.COLOR_BGR2RGB)
    face_locations = face_recognition.face_locations(rgb_img)
    face_encodings = face_recognition.face_encodings(rgb_img, face_locations)

    face_names = []
    for face_encoding in face_encodings:
        matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
        name = "Unknown"
        face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
        best_match_index = np.argmin(face_distances)
        if matches[best_match_index]:
            name = known_face_names[best_match_index]
        face_names.append(name)

    for face_loc, name in zip(face_locations, face_names):
        y1, x2, y2, x1 = face_loc[0], face_loc[1], face_loc[2], face_loc[3]
        y1=y1*multiple
        x2=x2*multiple
        y2=y2*multiple
        x1=x1*multiple
        cv2.putText(img, name, (x1, y1 - 10), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 200, 0), 2)
        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 200, 0), 4)

    cv2.imshow("Frame", img)
    key = cv2.waitKey(1)
    if key in (ord('q'), ord('Q')):
        break

cap.release()
cv2.destroyAllWindows()
