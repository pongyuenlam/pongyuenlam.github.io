**face08.py**

Encode the known faces in the "images" folder, then open the camera, shrink each frame to half size so that faces are found faster, recognise the faces in the live video, and draw a green box around each face with the person's name, or "Unknown" if the face does not match anyone, until the user presses `q` or `Q` to quit. It does the same as face07.py, but faster.

**Lines 1-5: Import the libraries**
```python
 1  import face_recognition
 2  import cv2
 3  import os
 4  import glob
 5  import numpy as np
```
- `face_recognition` is the library that finds faces in an image and turns each face into numbers that can be compared with other faces.
- `cv2` is **OpenCV**, the computer vision library used to read images and video, convert their colours, resize them, draw on them, and display them.
- `os` stands for **operating system**. It is Python's built-in module for working with the computer's files and folders. It handles file paths, such as joining folder and file names, or splitting a file name from its extension.
- `glob` stands for **global**. It finds all files whose names match a pattern, such as `*.*` (any name with any extension).
- `numpy` is **NumPy** (**Numerical Python**), a library for working with lists of numbers. `as np` gives it the short name `np`.

**Lines 6-7: Find all the images in the folder**
```python
 6  images_folder = "images"
 7  images_path = glob.glob(os.path.join(images_folder, "*.*"))
```
- Line 6 stores the folder name `"images"` in a variable.
- Line 7 builds the pattern `images/*.*` with `os.path.join` (which uses the correct `/` or `\` for Mac or Windows), and `glob.glob` returns a list of every matching file path, e.g. `["images/Howard.JPG", "images/Paul.jpg", "images/Mary.jpg"]`.

**Lines 9-10: Create two empty lists for the known faces**
```python
 9  known_face_encodings=[]
10  known_face_names=[]
```
- Line 9 creates an empty list that will hold the face encoding of each known person.
- Line 10 creates an empty list that will hold each person's name. The two lists are filled in the same order, so the first encoding belongs to the first name, and so on.

**Lines 11-15: Read each known image, convert its colours, and get the person's name**
```python
11  for img_path in images_path:
12      img = cv2.imread(img_path)
13      rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
14      basename = os.path.basename(img_path)
15      (filename, ext) = os.path.splitext(basename)
```
- Line 11 loops through the list, taking one file path at a time into `img_path`. Everything indented in lines 12-18 runs once per image.
- Line 12 reads the image file into `img`, a grid of pixel values in Blue Green Red (BGR) colour order.
- Line 13 uses `cvtColor` (**convert colour**) to change the colour order from BGR to RGB (**Red Green Blue**), and stores the result in `rgb_img`. OpenCV reads images as BGR, but `face_recognition` expects RGB.
- Line 14 removes the folder part: `images/Howard.JPG` becomes `Howard.JPG`.
- Line 15 splits the name from its extension: `Howard.JPG` becomes `("Howard", ".JPG")`, stored in `filename` and `ext`.

**Lines 16-18: Encode each known face and save it with the person's name**
```python
16      img_encoding = face_recognition.face_encodings(rgb_img)[0]
17      known_face_encodings.append(img_encoding)
18      known_face_names.append(filename)
```
- Line 16 turns the face in the image into a face encoding: a list of 128 numbers that describes that face. `[0]` takes the first face found, so each known image should contain one clear face.
- Line 17 adds the encoding to the end of `known_face_encodings` with `append`.
- Line 18 adds the person's name, e.g. `Howard`, to the end of `known_face_names`.

**Lines 20-26: Open the camera and work out the smaller frame size**
```python
20  cap = cv2.VideoCapture(0)
21  scale_ratio = 0.5
22  multiple = int(1 / scale_ratio)
23  ret, img = cap.read()
24  width=int(img.shape[1]*scale_ratio)
25  height=int(img.shape[0]*scale_ratio)
26  dim=(width,height)
```
- Line 20 opens the camera with `VideoCapture` and stores it in `cap` (**capture**). `0` means the computer's default camera, usually the built-in webcam.
- Line 21 sets `scale_ratio` to `0.5`, which means each frame will be shrunk to half its width and half its height.
- Line 22 works out `multiple`, the number used later to scale the face boxes back up to full size: `1 / 0.5` is `2`. `int` (**integer**) turns it into a whole number.
- Line 23 reads one frame from the camera, only to find out how big the camera's frames are. `ret` (**return value**) is `True` if a frame was read.
- Lines 24-25 work out the smaller size. `img.shape` gives the frame's size as (height, width, colours), so `shape[1]` is the width and `shape[0]` is the height. Each is multiplied by `0.5`, e.g. a 1280 × 720 frame becomes 640 × 360.
- Line 26 puts the smaller width and height together in `dim` (**dimensions**), ready for line 30.

**Lines 28-33: Read each frame, shrink it, and find the faces**
```python
28  while True:
29      ret, img = cap.read()
30      resized=cv2.resize(img,dim,interpolation=cv2.INTER_NEAREST)
31      rgb_img = cv2.cvtColor(resized,cv2.COLOR_BGR2RGB)
32      face_locations = face_recognition.face_locations(rgb_img)
33      face_encodings = face_recognition.face_encodings(rgb_img, face_locations)
```
- Line 28 starts a loop that repeats forever, because `True` is always true. Everything indented in lines 29-57 runs again and again until the user quits.
- Line 29 reads one frame (one still picture) from the camera into `img`, in BGR colour order.
- Line 30 shrinks the frame to the size in `dim` and stores it in `resized`. `interpolation` is how the new pixels are worked out; `INTER_NEAREST` (**nearest neighbour**) simply copies the nearest pixel, which is the fastest method. The full-size `img` is kept for display.
- Line 31 converts the small frame from BGR to RGB (**Red Green Blue**), because `face_recognition` expects RGB.
- Line 32 finds every face in the small frame. `face_locations` is a list with one position (a box around the face) for each face found.
- Line 33 turns each of those faces into a face encoding.
- The small frame has only a quarter of the pixels (half the width × half the height), so lines 32-33 run much faster than in face07.py, and the video is smoother.

**Lines 35-40: Compare each face with the known faces and find the most similar one**
```python
35      face_names = []
36      for face_encoding in face_encodings:
37          matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
38          name = "Unknown"
39          face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
40          best_match_index = np.argmin(face_distances)
```
- Line 35 creates an empty list for the names of the faces in this frame.
- Line 36 loops through the faces in the frame, one encoding at a time. Everything indented in lines 37-43 runs once per face.
- Line 37 compares this face with each known face and gives one `True` (match) or `False` (no match) for each known person. A face counts as a match only if its distance (line 39) is 0.6 or less.
- Line 38 sets `name` to `"Unknown"` as a starting value, in case no known face matches.
- Line 39 measures how different this face is from each known face. A smaller distance means the faces are more similar.
- Line 40 uses `np.argmin` (**argument of the minimum**) to find the position of the smallest distance, i.e. the most similar known face. Positions start at 0, so `0` means the first person (Howard), `1` the second (Paul), and `2` the third (Mary).

**Lines 41-43: Choose the name and save it**
```python
41          if matches[best_match_index]:
42              name = known_face_names[best_match_index]
43          face_names.append(name)
```
- Line 41 checks that the most similar known face is also a match (`True` in line 37). Being the most similar is not enough; it also has to be similar enough.
- Line 42 changes `name` to the person's name at that position, e.g. position `0` gives `Howard`.
- Line 43 adds the name to `face_names`. It is outside the `if`, so it runs for every face: a matched face adds the person's name, and any other face adds `"Unknown"`. This keeps `face_names` in the same order as `face_locations`, one name per face.

**Lines 45-50: Get each face's box and scale it back to full size**
```python
45      for face_loc, name in zip(face_locations, face_names):
46          y1, x2, y2, x1 = face_loc[0], face_loc[1], face_loc[2], face_loc[3]
47          y1=y1*multiple
48          x2=x2*multiple
49          y2=y2*multiple
50          x1=x1*multiple
```
- Line 45 uses `zip` to pair each face location with its name, like the two sides of a zip: the 1st location with the 1st name, the 2nd with the 2nd, and so on. Everything indented in lines 46-52 runs once per face.
- Line 46 takes the four sides of the face's box. `face_recognition` gives them in the order top, right, bottom, left, so they are stored as `y1` (top), `x2` (right), `y2` (bottom) and `x1` (left).
- Lines 47-50 multiply each side by `multiple` (`2`). The faces were found in the half-size frame, but the box is drawn on the full-size `img`, so the positions must be doubled, e.g. a top of `100` in the small frame becomes `200` in the full frame.

**Lines 51-52: Draw the box and the name**
```python
51          cv2.putText(img, name, (x1, y1 - 10), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 200, 0), 2)
52          cv2.rectangle(img, (x1, y1), (x2, y2), (0, 200, 0), 4)
```
- Line 51 writes the face's `name` 10 pixels above the box, as in face06.py. The colour `(0, 200, 0)` is in BGR order, so it means **green**.
- Line 52 draws a green rectangle around the face from the top-left corner `(x1, y1)` to the bottom-right corner `(x2, y2)`, with lines 4 pixels thick.

**Lines 54-57: Show the frame and quit when the user presses q or Q**
```python
54      cv2.imshow("Frame", img)
55      key = cv2.waitKey(1)
56      if key in (ord('q'), ord('Q')):
57          break
```
- Line 54 displays the full-size frame, with the boxes and names drawn on it, in a window titled `"Frame"`.
- Line 55 waits 1 millisecond for a key press and stores the key in `key`. If no key is pressed, `key` is `-1`. This short wait also gives OpenCV time to update the window.
- Line 56 uses `ord` (**ordinal**) to get the number code of the letters `q` and `Q`, because `waitKey` gives keys as numbers. It checks whether the key pressed is either of them.
- Line 57 uses `break` to leave the `while` loop, which stops the video.

**Lines 59-60: Close the camera and the window**
```python
59  cap.release()
60  cv2.destroyAllWindows()
```
- Line 59 is not indented, so it runs once after the loop ends. It releases the camera so that other apps can use it, and the camera light turns off.
- Line 60 closes every window that OpenCV opened.
