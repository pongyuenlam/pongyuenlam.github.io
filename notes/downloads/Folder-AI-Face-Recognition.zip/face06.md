**face06.py**

Open the computer's camera, draw a red box with the label "This is a test" on the live video, and show it in a window until the user presses `q` or `Q` to quit.

**Lines 1-2: Import the library and open the camera**
```python
 1  import cv2
 2  cap = cv2.VideoCapture(0)
```
- `cv2` is **OpenCV**, the computer vision library used here to read video from the camera, draw on it, and display it.
- Line 2 opens the camera with `VideoCapture` and stores it in `cap` (**capture**). `0` means the computer's default camera, usually the built-in webcam. If you have a second camera, `1` would open that one.

**Lines 3-4: Read the video, one frame at a time**
```python
 3  while True:
 4      ret, img = cap.read()
```
- Line 3 starts a loop that repeats forever, because `True` is always true. Everything indented in lines 4-12 runs again and again until the user quits.
- Line 4 reads one frame (one still picture) from the camera. `ret` (**return value**) is `True` if a frame was read, and `img` is the frame itself, a grid of pixel values in Blue Green Red (BGR) colour order.

**Lines 5-6: Set the corners of the box**
```python
 5      x1, y1 = 100, 200
 6      x2, y2 = x1 + 200, y1 + 150
```
- Positions in an image are measured in pixels from the **top-left corner**. `x` goes to the right and `y` goes **down** (not up, as in a maths graph).
- Line 5 sets the top-left corner of the box: 100 pixels from the left and 200 pixels from the top.
- Line 6 sets the bottom-right corner by adding the box's size: 200 pixels wide and 150 pixels tall. So `(x2, y2)` is `(300, 350)`.

**Lines 7-9: Draw the box and the label, then show the frame**
```python
 7      cv2.rectangle(img, (x1, y1), (x2, y2), (0, 0, 255), 2)
 8      cv2.putText(img, "This is a test", (x1, y1 - 10), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 0, 255), 2)
 9      cv2.imshow("Frame", img)
```
- Line 7 draws a rectangle on `img` from the top-left corner `(x1, y1)` to the bottom-right corner `(x2, y2)`. The colour `(0, 0, 255)` is in BGR order, so it means no blue, no green and full red: **red**. The last number, `2`, is the line thickness in pixels.
- Line 8 writes the text `"This is a test"` on `img`. In order, the values are:
  - `(x1, y1 - 10)`: the bottom-left corner of the text, 10 pixels above the box, so the label sits just on top of it
  - `cv2.FONT_HERSHEY_DUPLEX`: the font, one of the simple Hershey fonts built into OpenCV
  - `1`: the text size
  - `(0, 0, 255)`: the colour, red, the same as the box
  - `2`: the thickness of the letters in pixels
- Line 9 displays the frame, now with the box and label drawn on it, in a window titled `"Frame"`. Because lines 7-8 run for every frame, the box and label stay in the same place while the video moves behind them.

**Lines 10-12: Quit when the user presses q or Q**
```python
10      key = cv2.waitKey(1)
11      if key in (ord('q'), ord('Q')):
12          break
```
- Line 10 waits 1 millisecond for a key press and stores the key in `key`. If no key is pressed, `key` is `-1`. This short wait also gives OpenCV time to update the window.
- Line 11 uses `ord` (**ordinal**) to get the number code of the letters `q` and `Q`, because `waitKey` gives keys as numbers. It checks whether the key pressed is either of them.
- Line 12 uses `break` to leave the `while` loop, which stops the video.

**Lines 13-14: Close the camera and the window**
```python
13  cap.release()
14  cv2.destroyAllWindows()
```
- Line 13 is not indented, so it runs once after the loop ends. It releases the camera so that other apps can use it, and the camera light turns off.
- Line 14 closes every window that OpenCV opened.
