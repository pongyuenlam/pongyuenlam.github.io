import face_recognition
import cv2
import os
import glob
import numpy as np

images_folder = "images"
images_path = glob.glob(os.path.join(images_folder, "*.*"))

known_face_encodings=[]
known_face_names=[]
for img_path in images_path:
    img = cv2.imread(img_path)
    rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    basename = os.path.basename(img_path)
    (filename, ext) = os.path.splitext(basename)
    img_encoding = face_recognition.face_encodings(rgb_img)[0]
    known_face_encodings.append(img_encoding)
    known_face_names.append(filename)

img=cv2.imread("image-source.JPG")
rgb_img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
face_locations = face_recognition.face_locations(rgb_img)
face_encodings = face_recognition.face_encodings(rgb_img, face_locations)

face_names = []
for face_encoding in face_encodings:
    matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
    print(matches)
    name = "Unknown"
    face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
    print(np.round(face_distances, 2))
    best_match_index = np.argmin(face_distances)
    print(best_match_index)
    if matches[best_match_index]:
        name = known_face_names[best_match_index]
        face_names.append(name)
print("The matched name's image file is",face_names)  

