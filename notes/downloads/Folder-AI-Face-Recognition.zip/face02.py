import face_recognition
import cv2
import os
import glob
images_folder = "images"
images_path = glob.glob(os.path.join(images_folder, "*.*"))
print("{} images in folder".format(len(images_path)))
known_face_encodings=[]
known_face_names=[]
for img_path in images_path:
    img = cv2.imread(img_path)
    rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    basename = os.path.basename(img_path)
    (filename, ext) = os.path.splitext(basename)
    img_encoding = face_recognition.face_encodings(rgb_img)[0]
    known_face_encodings.append(img_encoding)
    known_face_names.append(filename)
    print("images encoded",filename)

