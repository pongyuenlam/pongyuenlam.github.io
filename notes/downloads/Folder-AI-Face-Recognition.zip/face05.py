import cv2
cap = cv2.VideoCapture(0)
while True:
    ret, img = cap.read()
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imshow("Frame", gray_img)
    key = cv2.waitKey(1)
    if key in (ord('q'), ord('Q')):  
        break
cap.release()
cv2.destroyAllWindows()
