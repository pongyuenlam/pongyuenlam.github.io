**face01.py**

Load every image file from the "images" folder and display each one for 1 second, printing the count of images found and each file's name (without extension) as it is shown.

**Lines 1-3: Import the libraries**
```python
 1  import cv2
 2  import os
 3  import glob
```
- `cv2` is **OpenCV**, the computer vision library used to read and display images.
- `os` stands for **operating system**. It is Python's built-in module for working with the computer's files and folders. It handles file paths, such as joining folder and file names, or splitting a file name from its extension.
- `glob` stands for **global**. It finds all files whose names match a pattern, such as `*.*` (any name with any extension).

**Lines 4-6: Find all the images in the folder**
```python
 4  images_folder = "images"
 5  images_path = glob.glob(os.path.join(images_folder, "*.*"))
 6  print("{} images in folder".format(len(images_path)))
```
- Line 4 stores the folder name `"images"` in a variable.
- Line 5 builds the pattern `images/*.*` with `os.path.join` (which uses the correct `/` or `\` for Mac or Windows), and `glob.glob` returns a list of every matching file path, e.g. `["images/Howard.JPG", "images/Paul.jpg", "images/Mary.jpg"]`.
- Line 6 counts the paths with `len()` which stands for **length** and prints a message such as `3 images in folder`. The `{}` is a placeholder that `.format()` fills with the number.

**Lines 7-10: Show each image for 1 second**
```python
 7  for img_path in images_path:
 8      img = cv2.imread(img_path)
 9      cv2.imshow("image",img)
10      cv2.waitKey(1000)
```
- Line 7 loops through the list, taking one file path at a time into `img_path`. Everything indented in lines 8-13 runs once per image.
- Line 8 reads the image file into `img`, a grid of pixel values in Blue Green Red (BGR) colour order.
- Line 9 displays the image in a window titled `"image"`. 
- Line 10 pauses for 1000 milliseconds (1 second) so we have time to view the image in the window.

**Lines 11-13: Print the file name without its folder or extension**
```python
11      basename = os.path.basename(img_path)
12      (filename, ext) = os.path.splitext(basename)
13      print(filename)
```
- Line 11 removes the folder part: `images/Howard.JPG` becomes `Howard.JPG`.
- Line 12 splits the name from its extension: `Howard.JPG` becomes `("Howard", ".JPG")`, stored in `filename` and `ext`.
- Line 13 prints just `Howard`. In a face recognition project, the file name is often used as the person's name, so this prepares the label for later programs.
