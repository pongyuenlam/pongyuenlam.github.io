**face09.py**

The same as face08.py, but with a tolerance setting that controls how similar a face must be to a known face to count as a match. Only the 2 lines that differ from face08.py are explained here. Because one line was added at line 7, every line after it is one number higher than in face08.py.

**Line 7: Set the tolerance**
```python
 7  my_tolerance = 0.5 # library default = 0.6
```
- Line 7 stores the tolerance in a variable. The tolerance is the largest distance between two faces that still counts as a match. The text after `#` is a comment that Python ignores. It notes that the library uses 0.6 if you don't set a tolerance, as in face08.py.
- A **lower** tolerance, such as 0.4 or 0.5, is stricter. You get fewer wrong names, but a known person may show as `"Unknown"` more often.
- A **higher** tolerance, such as 0.6 or 0.7, is looser. Known people are recognised more easily, but a stranger may be given the name of the most similar known person.

**Line 38: Use the tolerance when comparing faces**
```python
38          matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=my_tolerance)
```
- Line 38 compares this face with each known face, as line 37 did in face08.py. The difference is `tolerance=my_tolerance`. A face now counts as a match only if its distance (line 40) is 0.5 or less, instead of 0.6 or less.
- `tolerance=` is the name of the setting inside the `compare_faces` function, so it must be spelled exactly like this. `my_tolerance` is the variable from line 7 that gives it its value.

**What range can the tolerance be?**

The package doesn't set a range. `tolerance` can be any number, and `compare_faces` just checks whether `face_distance <= tolerance`.

The distances it's compared against do fall in a predictable range:

- **0** means two identical encodings.
- **About 0.3-0.5** is typical for two photos of the same person.
- **About 0.7 and above** is typical for two different people.
- The face encodings are scaled to a length of about 1, so a distance can't really go above about 2. In practice it rarely goes above about 1.2.

So the tolerances that are actually useful are roughly **0.4 to 0.7**:

| Tolerance | Effect |
|---|---|
| 0 | Almost nothing matches |
| 0.4-0.5 | Strict: fewer wrong names, more "Unknown" |
| 0.6 | Library default, which the docs call the typical best |
| 0.7+ | Loose: strangers start getting known people's names |
| 1.0+ | Almost everything matches |

The package's own advice is that lower is stricter, and to try a value below 0.6 if different people are being matched as the same person.
