**face07.py**

Encode the known faces in the "images" folder, then open the camera, recognise the faces in the live video, and draw a green box around each face with the person's name, or "Unknown" if the face does not match anyone, until the user presses `q` or `Q` to quit.

**Lines 1-5: Import the libraries**
```python
 1  import face_recognition
 2  import cv2
 3  import os
 4  import glob
 5  import numpy as np
```
- `face_recognition` is the library that finds faces in an image and turns each face into numbers that can be compared with other faces.
- `cv2` is **OpenCV**, the computer vision library used to read images and video, convert their colours, draw on them, and display them.
- `os` stands for **operating system**. It is Python's built-in module for working with the computer's files and folders. It handles file paths, such as joining folder and file names, or splitting a file name from its extension.
- `glob` stands for **global**. It finds all files whose names match a pattern, such as `*.*` (any name with any extension).
- `numpy` is **NumPy** (**Numerical Python**), a library for working with lists of numbers. `as np` gives it the short name `np`.

**Lines 6-7: Find all the images in the folder**
```python
 6  images_folder = "images"
 7  images_path = glob.glob(os.path.join(images_folder, "*.*"))
```
- Line 6 stores the folder name `"images"` in a variable.
- Line 7 builds the pattern `images/*.*` with `os.path.join` (which uses the correct `/` or `\` for Mac or Windows), and `glob.glob` returns a list of every matching file path, e.g. `["images/Howard.JPG", "images/Paul.jpg", "images/Mary.jpg"]`.

**Lines 9-10: Create two empty lists for the known faces**
```python
 9  known_face_encodings=[]
10  known_face_names=[]
```
- Line 9 creates an empty list that will hold the face encoding of each known person.
- Line 10 creates an empty list that will hold each person's name. The two lists are filled in the same order, so the first encoding belongs to the first name, and so on.

**Lines 11-15: Read each known image, convert its colours, and get the person's name**
```python
11  for img_path in images_path:
12      img = cv2.imread(img_path)
13      rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
14      basename = os.path.basename(img_path)
15      (filename, ext) = os.path.splitext(basename)
```
- Line 11 loops through the list, taking one file path at a time into `img_path`. Everything indented in lines 12-18 runs once per image.
- Line 12 reads the image file into `img`, a grid of pixel values in Blue Green Red (BGR) colour order.
- Line 13 uses `cvtColor` (**convert colour**) to change the colour order from BGR to RGB (**Red Green Blue**), and stores the result in `rgb_img`. OpenCV reads images as BGR, but `face_recognition` expects RGB.
- Line 14 removes the folder part: `images/Howard.JPG` becomes `Howard.JPG`.
- Line 15 splits the name from its extension: `Howard.JPG` becomes `("Howard", ".JPG")`, stored in `filename` and `ext`.

**Lines 16-18: Encode each known face and save it with the person's name**
```python
16      img_encoding = face_recognition.face_encodings(rgb_img)[0]
17      known_face_encodings.append(img_encoding)
18      known_face_names.append(filename)
```
- Line 16 turns the face in the image into a face encoding: a list of 128 numbers that describes that face. `[0]` takes the first face found, so each known image should contain one clear face.
- Line 17 adds the encoding to the end of `known_face_encodings` with `append`.
- Line 18 adds the person's name, e.g. `Howard`, to the end of `known_face_names`.

**Lines 20-22: Open the camera and read the video, one frame at a time**
```python
20  cap = cv2.VideoCapture(0)
21  while True:
22      ret, img = cap.read()
```
- Line 20 opens the camera with `VideoCapture` and stores it in `cap` (**capture**). `0` means the computer's default camera, usually the built-in webcam.
- Line 21 starts a loop that repeats forever, because `True` is always true. Everything indented in lines 22-45 runs again and again until the user quits.
- Line 22 reads one frame (one still picture) from the camera. `ret` (**return value**) is `True` if a frame was read, and `img` is the frame itself, in BGR colour order.

**Lines 23-25: Find and encode the faces in the frame**
```python
23      rgb_img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
24      face_locations = face_recognition.face_locations(rgb_img)
25      face_encodings = face_recognition.face_encodings(rgb_img, face_locations)
```
- Line 23 converts the frame from BGR to RGB, as in line 13.
- Line 24 finds every face in the frame. `face_locations` is a list with one position (a box around the face) for each face found.
- Line 25 turns each of those faces into a face encoding. There is no `[0]`, so it keeps the encodings of all the faces in the frame.
- Finding and encoding faces takes time, and these lines run for every frame, so the video may look slower or jerkier than in face04.py.

**Lines 27-32: Compare each face with the known faces and find the most similar one**
```python
27      face_names = []
28      for face_encoding in face_encodings:
29          matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
30          name = "Unknown"
31          face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
32          best_match_index = np.argmin(face_distances)
```
- Line 27 creates an empty list for the names of the faces in this frame.
- Line 28 loops through the faces in the frame, one encoding at a time. Everything indented in lines 29-35 runs once per face.
- Line 29 compares this face with each known face and gives one `True` (match) or `False` (no match) for each known person. A face counts as a match only if its distance (line 31) is 0.6 or less.
- Line 30 sets `name` to `"Unknown"` as a starting value, in case no known face matches.
- Line 31 measures how different this face is from each known face. A smaller distance means the faces are more similar.
- Line 32 uses `np.argmin` (**argument of the minimum**) to find the position of the smallest distance, i.e. the most similar known face. Positions start at 0, so `0` means the first person (Howard), `1` the second (Paul), and `2` the third (Mary).

**Lines 33-35: Choose the name and save it**
```python
33          if matches[best_match_index]:
34              name = known_face_names[best_match_index]
35          face_names.append(name)
```
- Line 33 checks that the most similar known face is also a match (`True` in line 29). Being the most similar is not enough; it also has to be similar enough.
- Line 34 changes `name` to the person's name at that position, e.g. position `0` gives `Howard`.
- Line 35 adds the name to `face_names`. It is outside the `if`, so it runs for every face: a matched face adds the person's name, and any other face adds `"Unknown"`. This keeps `face_names` in the same order as `face_locations`, one name per face.

**Lines 37-40: Draw a box and a name around each face**
```python
37      for face_loc, name in zip(face_locations, face_names):
38          y1, x2, y2, x1 = face_loc[0], face_loc[1], face_loc[2], face_loc[3]
39          cv2.putText(img, name, (x1, y1 - 10), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 200, 0), 2)
40          cv2.rectangle(img, (x1, y1), (x2, y2), (0, 200, 0), 4)
```
- Line 37 uses `zip` to pair each face location with its name, like the two sides of a zip: the 1st location with the 1st name, the 2nd with the 2nd, and so on. Everything indented in lines 38-40 runs once per face.
- Line 38 takes the four sides of the face's box. `face_recognition` gives them in the order top, right, bottom, left, so they are stored as `y1` (top), `x2` (right), `y2` (bottom) and `x1` (left).
- Line 39 writes the face's `name` 10 pixels above the box, as in face06.py. The colour `(0, 200, 0)` is in BGR order, so it means **green**.
- Line 40 draws a green rectangle around the face from the top-left corner `(x1, y1)` to the bottom-right corner `(x2, y2)`, with lines 4 pixels thick.

**Lines 42-45: Show the frame and quit when the user presses q or Q**
```python
42      cv2.imshow("Frame", img)
43      key = cv2.waitKey(1)
44      if key in (ord('q'), ord('Q')):
45          break
```
- Line 42 displays the frame, with the boxes and names drawn on it, in a window titled `"Frame"`.
- Line 43 waits 1 millisecond for a key press and stores the key in `key`. If no key is pressed, `key` is `-1`. This short wait also gives OpenCV time to update the window.
- Line 44 uses `ord` (**ordinal**) to get the number code of the letters `q` and `Q`, because `waitKey` gives keys as numbers. It checks whether the key pressed is either of them.
- Line 45 uses `break` to leave the `while` loop, which stops the video.

**Lines 47-48: Close the camera and the window**
```python
47  cap.release()
48  cv2.destroyAllWindows()
```
- Line 47 is not indented, so it runs once after the loop ends. It releases the camera so that other apps can use it, and the camera light turns off.
- Line 48 closes every window that OpenCV opened.
