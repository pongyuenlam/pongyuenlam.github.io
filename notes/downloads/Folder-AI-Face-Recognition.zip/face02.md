**face02.py**

Load every image in the "images" folder, turn the face in each image into a list of numbers (a face encoding), and save each encoding together with the person's name taken from the file name.

**Lines 1-4: Import the libraries**
```python
 1  import face_recognition
 2  import cv2
 3  import os
 4  import glob
```
- `face_recognition` is the library that finds faces in an image and turns each face into numbers that can be compared with other faces.
- `cv2` is **OpenCV**, the computer vision library used to read images and convert their colours.
- `os` stands for **operating system**. It is Python's built-in module for working with the computer's files and folders. It handles file paths, such as joining folder and file names, or splitting a file name from its extension.
- `glob` stands for **global**. It finds all files whose names match a pattern, such as `*.*` (any name with any extension).

**Lines 5-7: Find all the images in the folder**
```python
 5  images_folder = "images"
 6  images_path = glob.glob(os.path.join(images_folder, "*.*"))
 7  print("{} images in folder".format(len(images_path)))
```
- Line 5 stores the folder name `"images"` in a variable.
- Line 6 builds the pattern `images/*.*` with `os.path.join` (which uses the correct `/` or `\` for Mac or Windows), and `glob.glob` returns a list of every matching file path, e.g. `["images/Howard.JPG", "images/Paul.jpg", "images/Mary.jpg"]`.
- Line 7 counts the paths with `len()` which stands for **length** and prints a message such as `3 images in folder`. The `{}` is a placeholder that `.format()` fills with the number.

**Lines 8-9: Create two empty lists to store the results**
```python
 8  known_face_encodings=[]
 9  known_face_names=[]
```
- Line 8 creates an empty list that will hold the face encoding of each known person.
- Line 9 creates an empty list that will hold each person's name. The two lists are filled in the same order, so the first encoding belongs to the first name, and so on.

**Lines 10-14: Read each image, convert its colours, and get the person's name**
```python
10  for img_path in images_path:
11      img = cv2.imread(img_path)
12      rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
13      basename = os.path.basename(img_path)
14      (filename, ext) = os.path.splitext(basename)
```
- Line 10 loops through the list, taking one file path at a time into `img_path`. Everything indented in lines 11-18 runs once per image.
- Line 11 reads the image file into `img`, a grid of pixel values in Blue Green Red (BGR) colour order.
- Line 12 uses `cvtColor` (**convert colour**) to change the colour order from BGR to RGB (**Red Green Blue**), and stores the result in `rgb_img`. OpenCV reads images as BGR, but `face_recognition` expects RGB.
- Line 13 removes the folder part: `images/Howard.JPG` becomes `Howard.JPG`.
- Line 14 splits the name from its extension: `Howard.JPG` becomes `("Howard", ".JPG")`, stored in `filename` and `ext`.

**Lines 15-18: Encode the face and save it with the person's name**
```python
15      img_encoding = face_recognition.face_encodings(rgb_img)[0]
16      known_face_encodings.append(img_encoding)
17      known_face_names.append(filename)
18      print("images encoded",filename)
```
- Line 15 finds the faces in the image and turns each one into a face encoding: a list of 128 numbers that describes that face. `[0]` takes the first face found. Each image should therefore contain one clear face; if no face is found, this line stops the program with an error.
- Line 16 adds the encoding to the end of `known_face_encodings` with `append`.
- Line 17 adds the person's name, e.g. `Howard`, to the end of `known_face_names`.
- Line 18 prints a progress message such as `images encoded Howard`.

After the loop, the two lists hold 3 encodings and 3 names (`Howard`, `Paul`, `Mary`), ready to be compared with new faces in later programs.
