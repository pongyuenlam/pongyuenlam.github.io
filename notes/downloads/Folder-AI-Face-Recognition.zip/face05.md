**face05.py**

Open the computer's camera and show its live video in black and white (grey) in a window until the user presses `q` or `Q` to quit.

**Lines 1-2: Import the library and open the camera**
```python
 1  import cv2
 2  cap = cv2.VideoCapture(0)
```
- `cv2` is **OpenCV**, the computer vision library used here to read video from the camera, convert it to grey, and display it.
- Line 2 opens the camera with `VideoCapture` and stores it in `cap` (**capture**). `0` means the computer's default camera, usually the built-in webcam. If you have a second camera, `1` would open that one.

**Lines 3-6: Read each frame, convert it to grey, and show it**
```python
 3  while True:
 4      ret, img = cap.read()
 5      gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
 6      cv2.imshow("Frame", gray_img)
```
- Line 3 starts a loop that repeats forever, because `True` is always true. Everything indented in lines 4-9 runs again and again until the user quits.
- Line 4 reads one frame (one still picture) from the camera. `ret` (**return value**) is `True` if a frame was read, and `img` is the frame itself, a grid of pixel values in Blue Green Red (BGR) colour order.
- Line 5 uses `cvtColor` (**convert colour**) to change the frame from BGR to grey, and stores the result in `gray_img`. A colour pixel has 3 values (blue, green and red), but a grey pixel has only 1, from 0 (black) to 255 (white). This is the only new line compared with face04.py.
- Line 6 displays the grey frame, `gray_img`, in a window titled `"Frame"`. Because the loop shows a new frame many times per second, it looks like live black-and-white video.

**Lines 7-9: Quit when the user presses q or Q**
```python
 7      key = cv2.waitKey(1)
 8      if key in (ord('q'), ord('Q')):
 9          break
```
- Line 7 waits 1 millisecond for a key press and stores the key in `key`. If no key is pressed, `key` is `-1`. This short wait also gives OpenCV time to update the window.
- Line 8 uses `ord` (**ordinal**) to get the number code of the letters `q` and `Q`, because `waitKey` gives keys as numbers. It checks whether the key pressed is either of them.
- Line 9 uses `break` to leave the `while` loop, which stops the video.

**Lines 10-11: Close the camera and the window**
```python
10  cap.release()
11  cv2.destroyAllWindows()
```
- Line 10 is not indented, so it runs once after the loop ends. It releases the camera so that other apps can use it, and the camera light turns off.
- Line 11 closes every window that OpenCV opened.
