import cv2
cap = cv2.VideoCapture(0)
while True:
    ret, img = cap.read()
    x1, y1 = 100, 200
    x2, y2 = x1 + 200, y1 + 150
    cv2.rectangle(img, (x1, y1), (x2, y2), (0, 0, 255), 2)
    cv2.putText(img, "This is a test", (x1, y1 - 10), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 0, 255), 2)
    cv2.imshow("Frame", img)
    key = cv2.waitKey(1) 
    if key in (ord('q'), ord('Q')):
        break
cap.release()
cv2.destroyAllWindows()
