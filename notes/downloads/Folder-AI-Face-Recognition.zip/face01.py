import cv2
import os
import glob
images_folder = "images"
images_path = glob.glob(os.path.join(images_folder, "*.*"))
print("{} images in folder".format(len(images_path)))
for img_path in images_path:
    img = cv2.imread(img_path)
    cv2.imshow("image",img)
    cv2.waitKey(1000) 
    basename = os.path.basename(img_path)
    (filename, ext) = os.path.splitext(basename)
    print(filename)
