# ReAct10 — one supervisor agent with three workers

Version 9 could read a page and number its sentences. Version 10 adds a
manager: a supervisor agent that has three tools, and two of those tools are
agents themselves.

1. `scrap_web` — download a page and list its sentences (plain Python, from
   version 9).
2. `translate_en_to_zh` — a translator agent, wrapped as a tool.
3. `zh_to_cantonese` — a Cantonese editor agent, wrapped as a tool, which
   also lists the sentences that changed.

We do **not** fix the order in our code. The supervisor decides which tool to
call, and when.

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with one line:

   ```
   DEEPSEEK_API_KEY=your-deepseek-key
   ```

   A key is available from the [DeepSeek console](https://platform.deepseek.com/api_keys).
3. In the Terminal, run these three lines, one at a time:

   ```
   uv python pin 3.12.10
   uv sync
   uv run ReAct10.py
   ```

The program makes three model calls (one per worker), so it takes longer than
the earlier versions.

## What to look at

- `########## SUPERVISOR gets the request ##########` — the request in plain
  English: "Give me the Cantonese version of every sentence on ...".
- `########## TOOL: ... ##########` — one block per tool, in the order the
  supervisor chose.
- `########## SUPERVISOR's plan ##########` — the list of tools it called.
- `########## SUPERVISOR's final answer ##########` — the Cantonese sentences,
  then the changed sentences, before → after.
- Try changing the request to "Give me the Traditional Chinese version of
  every sentence on ...". The supervisor should stop before
  `zh_to_cantonese`, because the AI chooses the tools, not the code.

## Limitations

- Every tool that calls a model costs time and money. Three workers means
  three calls, and a long page makes each call bigger.
- The supervisor can pick a sensible order, but it can also pick a wrong one.
  Read the plan it prints.
- Each tool must pass the previous tool's output along unchanged, or the
  numbering breaks. The system prompt asks for this, but a model can still
  shorten a long list.
- The page must be readable with `requests` and `BeautifulSoup`; a page built
  by JavaScript returns almost nothing.
- There is no error handling: if the site is down, the program stops.
