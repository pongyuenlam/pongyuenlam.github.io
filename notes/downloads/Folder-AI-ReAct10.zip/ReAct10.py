# MULTIPLE AGENTS with a SUPERVISOR (manager), built with LangChain.
# The supervisor is an agent whose tools are other workers:
#   1) scrap_web          -> reads a web page and lists every sentence (plain Python, code from ReAct09.py)
#   2) translate_en_to_zh -> a translator AGENT, wrapped as a tool
#   3) zh_to_cantonese    -> a Cantonese editor AGENT, wrapped as a tool
# We do NOT fix the order in our code: the supervisor (the AI) decides which tool to call, and when.
import os
import re
import requests
from bs4 import BeautifulSoup
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent
from dotenv import load_dotenv
load_dotenv()

URL = "https://pongyuenlam.github.io/biography.html"
USER_AGENT = "ReAct10-class-demo"   # tells the website who is visiting

my_model = ChatOpenAI(
    model="deepseek-flash",
    api_key=os.environ.get('DEEPSEEK_API_KEY'),
    base_url="https://api.deepseek.com")

def ask_agent(agent, message):
    """Give a worker agent its input and return its final reply."""
    result = agent.invoke({"messages": [{"role": "user", "content": message}]})
    return result["messages"][-1].content

# ---- Three tools for the supervisor ----
@tool
def scrap_web(url: str) -> str:
    """Download a web page and return its English sentences, one per line, numbered."""
    response = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=10)
    soup = BeautifulSoup(response.text, "html.parser")
    sentences = []
    for element in soup.find_all(["h1", "h2", "h3", "p", "li"]):
        text = re.sub(r"\s+", " ", element.get_text(" ", strip=True))
        if text:
            sentences.extend(re.split(r"(?<=[.!?])\s+", text))
    result = "\n".join(f"{number}. {sentence}"
                       for number, sentence in enumerate(sentences, start=1))
    print(f"\n########## TOOL: scrap_web ##########\n{result}")
    return result

@tool
def translate_en_to_zh(sentences: str) -> str:
    """Translate numbered English sentences into numbered Traditional Chinese sentences."""
    # A worker agent: same model, its own job (system_prompt), no tools
    translator_agent = create_agent(
        model=my_model,
        tools=[],
        system_prompt="""You are a professional English to Traditional Chinese (繁體中文) translator.
Translate each numbered sentence into formal written Traditional Chinese.
Keep the same numbers, one sentence per line. Keep names, URLs and abbreviations (e.g. PhD, AI) as they are.
Reply with ONLY the numbered translations.""",
    )
    result = ask_agent(translator_agent, sentences)
    print(f"\n########## TOOL: translate_en_to_zh ##########\n{result}")
    return result

@tool
def zh_to_cantonese(sentences: str) -> str:
    """Rewrite numbered Traditional Chinese sentences into numbered spoken Cantonese sentences,
    then list the sentences that changed (before -> after)."""
    # A worker agent: same model, its own job (system_prompt), no tools
    cantonese_agent = create_agent(
        model=my_model,
        tools=[],
        system_prompt="""You are a Hong Kong Cantonese editor.
Rewrite each numbered Traditional Chinese sentence into natural spoken Cantonese (廣東話口語),
the way a Hong Kong person would say it, e.g. 是 -> 係, 的 -> 嘅, 他 -> 佢, 沒有 -> 冇.
Keep the same numbers, one sentence per line. Keep names, URLs and abbreviations as they are.
Reply with ONLY the numbered Cantonese sentences.""",
    )
    result = ask_agent(cantonese_agent, sentences)

    # Another list: compare before (Chinese) and after (Cantonese), sentence by sentence, using the numbers
    before = dict(re.findall(r"^(\d+)\.\s*(.*)$", sentences, re.M))   # {"1": "他是...", "2": ...}
    after = dict(re.findall(r"^(\d+)\.\s*(.*)$", result, re.M))
    changes = [f"{number}. {before[number]}\n   -> {after[number]}"
               for number in before
                if (number in after) and (before[number] != after[number])]
    result = (result + f"\n\nChanged sentences ({len(changes)} of {len(before)}), before -> after:\n"
              + "\n".join(changes))
    print(f"\n########## TOOL: zh_to_cantonese ##########\n{result}")
    return result

# ---- The supervisor: decides which tools to use, and in what order ----
supervisor = create_agent(
    model=my_model,
    tools=[scrap_web, translate_en_to_zh, zh_to_cantonese],
    system_prompt="""You are a supervisor managing a team of tools.
Plan which tools are needed for the user's request, and call them in a sensible order.
When you pass one tool's output to the next tool, pass ALL of it, exactly as it is: do not shorten or change it.
At the end, reply with the final numbered sentences, followed by the list of changed sentences if a tool gave one.""",
)

request = f"Give me the Cantonese version of every sentence on {URL}"
print(f"########## SUPERVISOR gets the request ##########\n{request}")
result = supervisor.invoke({"messages": [{"role": "user", "content": request}]})

# Show the plan the supervisor made: which tools it called, in order
print("\n########## SUPERVISOR's plan (tools called, in order) ##########")
for message in result["messages"]:
    for call in getattr(message, "tool_calls", None) or []:
        print(f"- {call['name']}")

print("\n########## SUPERVISOR's final answer ##########")
print(result["messages"][-1].content)

# Try it: change the request to "Give me the Traditional Chinese version of every sentence on ..."
# Does the supervisor still call zh_to_cantonese? It should not — the AI chooses the tools.
