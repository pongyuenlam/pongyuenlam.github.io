from PIL import Image, ImageDraw
import face_recognition
image = face_recognition.load_image_file("my_photo.jpg")
face_landmarks_list = face_recognition.face_landmarks(image)
pil_image = Image.fromarray(image)
for face_landmarks in face_landmarks_list:
    d = ImageDraw.Draw(pil_image, 'RGBA')
    # (red, green, blue, see-through): each 0 to 255; see-through 0 = invisible, 255 = solid
    color_eyebrow = (68, 54, 39, 128)
    d.polygon(face_landmarks['left_eyebrow'], fill=color_eyebrow)
    d.polygon(face_landmarks['right_eyebrow'], fill=color_eyebrow)
    pil_image.save("my_photo_eyebrow.jpg")