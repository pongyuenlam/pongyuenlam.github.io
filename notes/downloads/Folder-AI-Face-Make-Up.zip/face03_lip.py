from PIL import Image, ImageDraw
import face_recognition
image = face_recognition.load_image_file("my_photo.jpg")
face_landmarks_list = face_recognition.face_landmarks(image)
pil_image = Image.fromarray(image)
for face_landmarks in face_landmarks_list:
    d = ImageDraw.Draw(pil_image, 'RGBA')
    color_lip = (150,0,0,125)
    # Fill the lip with color_lip
    d.polygon(face_landmarks['top_lip'], fill=color_lip)
    d.polygon(face_landmarks['bottom_lip'], fill=color_lip)
    d.line(face_landmarks['top_lip'], fill=color_lip, width=8)
    d.line(face_landmarks['bottom_lip'], fill=color_lip, width=8)
    pil_image.save("my_photo_lip.jpg")