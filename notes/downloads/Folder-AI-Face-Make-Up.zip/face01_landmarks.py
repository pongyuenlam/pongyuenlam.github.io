# https://github.com/ageitgey/face_recognition
# https://github.com/ageitgey/face_recognition/blob/master/examples/find_facial_features_in_picture.py
from PIL import Image, ImageDraw
import face_recognition
image = face_recognition.load_image_file("my_photo.jpg")
face_landmarks_list = face_recognition.face_landmarks(image)
pil_image = Image.fromarray(image)
# Make the dots and lines bigger for bigger pictures
size = max(2, pil_image.width // 300)
color_line = (0, 255, 0)
color_point = (255, 0, 0)
for face_landmarks in face_landmarks_list:
    d = ImageDraw.Draw(pil_image)
    # Each face part is a list of key points, e.g. 'chin' has 17 points
    for facial_feature, points in face_landmarks.items():
        print(facial_feature, len(points), "points")
        # Eyes and lips are closed shapes, so join the last point back to the first
        if facial_feature in ['left_eye', 'right_eye', 'top_lip', 'bottom_lip']:
            d.line(points + [points[0]], fill=color_line, width=size)
        else:
            d.line(points, fill=color_line, width=size)
        # Draw a dot on every key point
        for x, y in points:
            d.ellipse([x - size * 2, y - size * 2, x + size * 2, y + size * 2], fill=color_point)
    pil_image.save("my_photo_landmarks.jpg")
