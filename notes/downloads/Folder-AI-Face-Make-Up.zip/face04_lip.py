from PIL import Image, ImageDraw
import face_recognition

# 10 colors of red: (red, green, blue, see-through)
# The 4th number is 0 (invisible) to 255 (solid)
colors = {
    'cherry':    (190, 20, 40, 120),
    'scarlet':   (230, 30, 20, 110),
    'crimson':   (170, 10, 50, 120),
    'ruby':      (155, 15, 70, 120),
    'brick':     (165, 50, 35, 110),
    'coral':     (240, 90, 80, 110),
    'rose':      (210, 70, 100, 110),
    'wine':      (115, 15, 40, 130),
    'burgundy':  (100, 10, 30, 140),
    'blood':     (140, 0, 0, 130),
}

image = face_recognition.load_image_file("my_photo.jpg")
face_landmarks_list = face_recognition.face_landmarks(image)
pil_image = Image.fromarray(image)
# Make the 10 colors one by one
for name, color_lip in colors.items():
    # Start from a fresh copy of the photo each time, so the colors do not pile up
    lip_image = pil_image.copy()
    d = ImageDraw.Draw(lip_image, 'RGBA')
    for face_landmarks in face_landmarks_list:
        # Fill the lip with color_lip
        d.polygon(face_landmarks['top_lip'], fill=color_lip)
        d.polygon(face_landmarks['bottom_lip'], fill=color_lip)
    # Save each color as an image file named after the color, e.g. lip_cherry.jpg
    lip_image.save("lip_" + name + ".jpg")
    print("Saved", "lip_" + name + ".jpg")
