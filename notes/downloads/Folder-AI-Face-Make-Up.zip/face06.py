import cv2
import face_recognition
import numpy as np
# Cherry red from face04_lip.py: (red, green, blue, see-through)
# OpenCV uses blue-green-red order, so the color is written backwards
color_lip = (40, 20, 190)
strength = 120 / 255          # how strong the lipstick is: 0 = none, 1 = solid
small = 0.25                  # look for the face in a picture 1/4 the size, so the video is fast
cap = cv2.VideoCapture(0)
while True:
    ret, img = cap.read()
    if not ret:
        break
    # face_recognition uses red-green-blue order, OpenCV uses blue-green-red
    small_img = cv2.resize(img, (0, 0), fx=small, fy=small)
    rgb_small_img = cv2.cvtColor(small_img, cv2.COLOR_BGR2RGB)
    face_landmarks_list = face_recognition.face_landmarks(rgb_small_img)
    # Mask: white where the lips are, black everywhere else
    mask = np.zeros(img.shape[0:2], dtype=np.uint8)
    for face_landmarks in face_landmarks_list:
        for lip in ['top_lip', 'bottom_lip']:
            # The landmarks were found on the small picture, so make them 4 times bigger
            points = (np.array(face_landmarks[lip]) / small).astype(np.int32)
            cv2.fillPoly(mask, [points], 255)
    # Soften the lip edges
    mask = cv2.GaussianBlur(mask, (7, 7), 0)
    # Mix the lip color into the picture where the mask is white
    alpha = (mask / 255 * strength)[:, :, None]
    img = (img * (1 - alpha) + np.array(color_lip) * alpha).astype(np.uint8)
    cv2.imshow("Frame", img)
    key = cv2.waitKey(1)
    if key in (ord('q'), ord('Q')):
        break
cap.release()
cv2.destroyAllWindows()
