import requests
from dotenv import load_dotenv
from livekit.agents import (
    Agent,
    AgentServer,
    AgentSession,
    JobContext,
    RunContext,
    cli,
    function_tool,
    inference,
)

load_dotenv()


def _geocode(city: str) -> tuple[float, float, str] | None:
    """Resolve a city name to (lat, lon, resolved_label) using Open-Meteo geocoding."""
    r = requests.get(
        "https://geocoding-api.open-meteo.com/v1/search",
        params={"name": city, "count": 1, "language": "zh", "format": "json"},
        timeout=10,
    )
    results = r.json().get("results")
    if not results:
        return None
    best = results[0]
    name = best.get("name", city)
    country = best.get("country")
    label = f"{name}，{country}" if country else name
    return best["latitude"], best["longitude"], label


def _ip_location() -> tuple[float, float, str] | None:
    """Resolve lat/lon AND a human-readable city/region label from the caller's IP."""
    try:
        info = requests.get("https://ipinfo.io/json", timeout=10).json()
        lat_str, lon_str = info["loc"].split(",")
        parts = [p for p in (info.get("city"), info.get("region"), info.get("country")) if p]
        label = "，".join(parts) if parts else "你所在的位置"
        return float(lat_str), float(lon_str), label
    except Exception:
        return None


def _fetch_weather(latitude: float, longitude: float) -> dict:
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "current": "temperature_2m,weather_code,relative_humidity_2m,apparent_temperature",
        "daily": "temperature_2m_max,temperature_2m_min,weather_code",
        "temperature_unit": "celsius",
        "timezone": "auto",
        "forecast_days": 1,
    }
    data = requests.get(
        "https://api.open-meteo.com/v1/forecast",
        params=params,
        timeout=10,
    ).json()
    return data


# WMO weather code -> short Chinese description
_WMO_CODES = {
    0: "晴空",
    1: "大致晴朗", 2: "部分多云", 3: "阴天",
    45: "雾", 48: "冻雾",
    51: "小毛毛雨", 53: "中等毛毛雨", 55: "大毛毛雨",
    56: "小冻毛毛雨", 57: "大冻毛毛雨",
    61: "小雨", 63: "中雨", 65: "大雨",
    66: "小冻雨", 67: "大冻雨",
    71: "小雪", 73: "中雪", 75: "大雪",
    77: "雪粒",
    80: "小阵雨", 81: "中阵雨", 82: "强阵雨",
    85: "小阵雪", 86: "大阵雪",
    95: "雷暴", 96: "雷暴伴小冰雹", 99: "雷暴伴大冰雹",
}


@function_tool
async def lookup_weather(
    context: RunContext,
    location: str = "",
):
    """
    Look up weather information. If the user mentions a specific city or
    place (e.g. "香港", "Hong Kong", "Mountain View"), pass it in. Otherwise —
    when the user says "这里", "我这边", "where I am", or does not name any
    place — call this tool with no location argument. It will automatically
    detect the user's approximate city from their IP address.
    """

    lat = lon = None
    resolved = ""

    if location and location.strip():
        geo = _geocode(location.strip())
        if geo:
            lat, lon, resolved = geo

    if lat is None:
        ip = _ip_location()
        if ip is None:
            return {"error": "无法自动判断你的位置。"}
        lat, lon, resolved = ip

    try:
        data = _fetch_weather(lat, lon)
    except Exception as e:
        return {"error": f"天气服务暂时不可用：{e}"}

    cur = data.get("current", {}) or {}
    daily = data.get("daily", {}) or {}
    code = cur.get("weather_code")
    condition = _WMO_CODES.get(code, f"代码 {code}") if code is not None else "未知"

    return {
        "location": resolved,
        "temperature_c": cur.get("temperature_2m"),
        "feels_like_c": cur.get("apparent_temperature"),
        "condition": condition,
        "humidity_percent": cur.get("relative_humidity_2m"),
        "today_high_c": (daily.get("temperature_2m_max") or [None])[0],
        "today_low_c": (daily.get("temperature_2m_min") or [None])[0],
    }


server = AgentServer()


@server.rtc_session()
async def entrypoint(ctx: JobContext):
    session = AgentSession(
        vad=inference.VAD(),
        # any combination of STT, LLM, TTS, or realtime API can be used
        # this example shows LiveKit Inference, a unified API to access different models via LiveKit Cloud
        # to use model provider keys directly, replace with the following:
        # from livekit.plugins import deepgram, openai, cartesia
        # stt=deepgram.STT(model="nova-3"),
        # llm=openai.LLM(model="gpt-4.1-mini"),
        # tts=cartesia.TTS(model="sonic-3", voice="9626c31c-bec5-4cca-baa8-f8ba9e84c8bc"),
        stt=inference.STT("deepgram/nova-3", language="zh-CN"),
        llm=inference.LLM("google/gemma-4-31b-it"),  # low-latency gemma, hosted on LiveKit
        tts=inference.TTS(
            "cartesia/sonic-3",
            voice="9626c31c-bec5-4cca-baa8-f8ba9e84c8bc",
            language="zh",
        ),
    )

    agent = Agent(
        instructions=(
            "You are a friendly voice assistant built by LiveKit. "
            "You always reply in Putonghua (Mandarin Chinese), in simplified "
            "characters, even when the user speaks English or Cantonese. "
            "You can answer weather questions. You do NOT need to ask the "
            "user which city they are in — if they do not name a specific "
            "city, just call lookup_weather() with no arguments and it will "
            "auto-detect their location. Only pass a location when the user "
            "explicitly names one (e.g. '香港天气怎么样？'). "
            "Never ask 'which city?' — always try to answer directly first. "
            "Keep answers short, because they will be spoken aloud."
        ),
        tools=[lookup_weather],
    )

    await session.start(agent=agent, room=ctx.room)
    await session.generate_reply(
        instructions="用普通话向用户打招呼，并问他今天过得怎么样。"
    )


if __name__ == "__main__":
    cli.run_app(server)
