# research04 — three tools, search, select, then write a draft

Version 4 adds a third tool. `search_internet` searches the web and saves the
response in `last_search`. `generate_draft` reads that saved response and keeps
only the results that pass its rule: a score of 0.5 or higher, and never
Wikipedia. `write_draft` then receives one sentence per kept result, copies them
in order, and adds a numbered endnote for each one. In the demo run, ten results
become seven, and the seven become a draft with seven endnotes.

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with two lines:

   ```
   TAVILY_API_KEY=your-tavily-key
   DEEPSEEK_API_KEY=your-deepseek-key
   ```

   A Tavily key is available from the [Tavily dashboard](https://app.tavily.com/home),
   and a DeepSeek key from the [DeepSeek console](https://platform.deepseek.com/api_keys).
3. In the Terminal, run these three lines, one at a time:

   ```
   uv python pin 3.12.10
   uv sync
   uv run research04.py
   ```

This version calls a language model once, so it needs both keys. It takes a
few seconds.

## What to look at

- `selected_results` — the second shared variable. The filter writes to it, and
  `write_draft` reads from it.
- `sentences: list[str]` — the model sends sentences, not results. The tool
  never opens a page; it only joins text and numbers the endnotes.
- `zip(sentences, selected_results)` — the pairing is by position: first
  sentence with first result, and so on. Nothing is matched by title or URL.
- `if sentence.strip() == ""` — an empty string means "no complete sentence in
  this page", and `continue` skips it without using up an endnote number.
- `f"[{endnote_num}] {r['url']}\n"` — the f-string fills in the number and the
  link, and `\n` puts each endnote on its own line.
- Three `Tool:` blocks on screen — search, filter, draft.

## Try it

- Delete the `if sentence.strip() == ""` lines and put `""` in the model's
  answer by hand. An endnote appears with no sentence under it.
- Change `zip(sentences, selected_results)` to
  `zip(sentences, reversed(selected_results))`. Every endnote now points at the
  wrong page.
- Change the system prompt from "copy it exactly" to "summarise it in your own
  words" and compare the draft. The text is smoother and no longer traceable.
- Remove `return_direct=True` and see what the model adds after the draft.

## Limitations

- A draft, not a report: quoted sentences in the order of the results, with
  nothing connecting them.
- The numbers disagree (7.371 million to 7.5 million), and the draft cannot
  resolve that.
- Copying is not checking: a copied sentence can still be out of date.
- Position decides the pairing, so one missing sentence shifts every endnote
  after it.
- A page with no complete sentence is silently left out.
