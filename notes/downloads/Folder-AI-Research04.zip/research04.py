import os
import json
from dotenv import load_dotenv
from tavily import TavilyClient
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent

load_dotenv()

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")

tavily_client = TavilyClient(api_key=TAVILY_API_KEY)

# Keeps the latest search response so generate_draft can use it
last_search = {}
# Keeps the results selected by generate_draft so write_draft can use them
selected_results = []

@tool
def search_internet(query: str):
    """
    Search the internet for up-to-date information about the query
    and return the full Tavily search response.
    """
    global last_search
    response = tavily_client.search(query, max_results=10)
    last_search = response
    return response


@tool
def generate_draft():
    """
    Go through the results from the latest search_internet call.
    Keep results with a score of 0.5 or higher, but never keep Wikipedia.
    Return the selected results.
    """
    global selected_results
    selected = []
    for r in last_search.get("results", []):
        if r["score"] >= 0.5 and "wikipedia.org" not in r["url"]:
            selected.append(r)

    selected_results = selected
    return {"query": last_search.get("query"), "results": selected}


@tool(return_direct=True)
def write_draft(sentences: list[str]):
    """
    Write a draft with endnotes from the results of generate_draft.
    sentences: one sentence per result from generate_draft, in the same order.
    Each sentence must be copied exactly from that result's content, and be
    the sentence closest in meaning to the user's query.
    Use an empty string "" for a result that has no complete sentence.
    """
    s = ""
    endnotes = ""
    endnote_num = 1
    for sentence, r in zip(sentences, selected_results):
        if sentence.strip() == "":
            continue  # skip results with no complete sentence
        s = s + sentence + "[" + str(endnote_num) + "] "
        endnotes = endnotes + f"[{endnote_num}] {r['url']}\n"
        endnote_num = endnote_num + 1

    s = s + "\n\nEndnotes:\n" + endnotes

    return s


model = ChatOpenAI(
    model="deepseek-flash",
    api_key=DEEPSEEK_API_KEY,
    base_url="https://api.deepseek.com",
    temperature=0,
)

agent = create_agent(
    model=model,
    tools=[search_internet, generate_draft, write_draft],
    system_prompt=(
        "You are a helpful assistant. "
        "Always call search_internet, using the user's message exactly as the query. "
        "Do not rephrase, shorten, translate, or add anything to it. "
        "Then call generate_draft to select the useful results. "
        "Then go through each sentence in each selected result, pick the one sentence "
        "closest in meaning to the user's query, and copy it exactly. "
        "A complete sentence has a subject and a verb and ends with a full stop; "
        "table rows, headings, menus and fragments are not complete sentences. "
        "If a result has no complete sentence, use an empty string \"\" for it. "
        "Call write_draft with these sentences in the same order as the results."
    ),
)

prompt = "What is the population of Hong Kong?"
result = agent.invoke({
    "messages": [{"role": "user", "content": prompt}]
})

for message in result["messages"]:
    if message.type == "tool" and message.name == "write_draft":
        print(f"Tool: {message.name}\n")
        print(message.content)
    elif message.type == "tool":
        response = json.loads(message.content)
        print(f"Tool: {message.name}")
        print(f"Query: {response['query']}\n")
        for i, r in enumerate(response["results"], start=1):
            print(f"{i}. {r['title']}  (score: {r['score']:.2f})")
            print(f"   {r['url']}")
            print(f"   {r['content'][:200].replace(chr(10), ' ')}...\n")
