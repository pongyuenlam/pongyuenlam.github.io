import os
import re
import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv
load_dotenv()
from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_openai import ChatOpenAI

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
my_model = ChatOpenAI(
    api_key=DEEPSEEK_API_KEY,
    base_url="https://api.deepseek.com",
    model_name="deepseek-chat"
)

embeddings = HuggingFaceEmbeddings(
    model_name="BAAI/bge-m3"
)

url = "https://www.panadol.com/en-gb/adult-symptoms/headache/"
headers = {"User-Agent": "Mozilla/5.0 (compatible; SkillBot/1.0)"}
resp = requests.get(url, headers=headers, timeout=15)
resp.raise_for_status()
resp.encoding = resp.apparent_encoding
soup = BeautifulSoup(resp.text, "html.parser")
for tag in soup(["script", "style", "noscript", "nav", "footer"]):
    tag.decompose()
lines = [" ".join(tag.get_text(" ").split()) for tag in soup.find_all(["h1", "h2", "h3", "p", "li"])]
lines = [line for line in lines if line != ""]

sentences = []
for line in lines:
    for sentence in re.split(r"(?<=[.!?])\s+(?=[A-Z])", line):
        sentences.append(sentence)
lines = sentences

with open("panadol.txt", "w", encoding="utf-8") as outfile:
    for line in lines:
        outfile.write(line + "\n")

chunked_text_with_metadata = []
for line_num, line in enumerate(lines, start=1):
    if line.strip() == "":
        continue
    content = f"line number {line_num}\n{line.strip()}"
    chunked_text_with_metadata.append(
        Document(
            page_content=content,
            metadata={"source": url, "line": line_num},
        )
    )

vectorstore = InMemoryVectorStore.from_documents(chunked_text_with_metadata, embeddings)
retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

print("Before RAG")
before_rag_template = "{topic}"
before_rag_prompt = ChatPromptTemplate.from_template(before_rag_template)
before_rag_chain = before_rag_prompt | my_model | StrOutputParser()
user_question = "How many people get headaches at least once a year?"
print(before_rag_chain.invoke({"topic": user_question}))

print("After RAG")
after_rag_template = """Answer the question based only on the following context:
{context} and give line number as well
Question: {question}
"""
after_rag_prompt = ChatPromptTemplate.from_template(after_rag_template)
after_rag_chain = (
    {"context": retriever, "question": RunnablePassthrough()}
    | after_rag_prompt
    | my_model
    | StrOutputParser()
)
results = after_rag_chain.invoke(user_question)
print(results)
