# research01 — search the web from Python

Version 1 of the research series. There is no AI agent here: the program asks
Tavily a question and prints ten search results. Each result shows its title,
score, URL and the first 200 characters of the page.

This is the material that every later version works on.

## Run it

1. Open the folder in Visual Studio Code.
2. Create a file named `.env` in the folder with one line:

   ```
   TAVILY_API_KEY=your-tavily-key
   ```

   A key is available from the [Tavily dashboard](https://app.tavily.com/home).
3. In the Terminal, run these three lines, one at a time:

   ```
   uv python pin 3.12.10
   uv sync
   uv run research01.py
   ```

No language model is called, so this version needs only the Tavily key. It
takes a few seconds.

## What to look at

- `Query: ...` — the question that was sent.
- `1. ... (score: 0.92)` — the number, the page title, and how well the page
  matches the question, from 0 to 1.
- The URL under each title — where the full page lives.
- The text under the URL — the first 200 characters, with line breaks turned
  into spaces so each result stays on three lines.

## Try it

- Change the question.
- Ask for fewer results:

  ```python
  response = tavily_client.search("What is the population of Hong Kong?", max_results=3)
  ```

## Limitations

- Nobody reads the results. The program prints them and stops.
- The preview is 200 characters, not the page. Open the URL for the full text.
- The score measures relevance, not accuracy. A page can match the words and
  still be out of date or wrong.
- Different pages give different figures — three results above give three
  different populations. Search finds sources; it does not settle them.
