import os
from dotenv import load_dotenv
load_dotenv()
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")

from tavily import TavilyClient

tavily_client = TavilyClient(api_key=TAVILY_API_KEY)
response = tavily_client.search("What is the population of Hong Kong?")

print(f"Query: {response['query']}\n")
for i, r in enumerate(response["results"], start=1):
    print(f"{i}. {r['title']}  (score: {r['score']:.2f})")
    print(f"   {r['url']}")
    print(f"   {r['content'][:200].replace(chr(10), ' ')}...\n") 